import * as types from "../actions";
import { combineReducers } from "redux";

function createPlanReducer(state = [], action) {
  let response = action.response;
  switch (action.type) {
    case types.CREAT_PLAN:
      return { loading: true, ...state };
    case types.CREATE_PLAN_SUCCESS:
      return { loading: false, response };
    case types.CREATE_PLAN_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

function getPlanReducer(state = [], action) {
  const response = action.response;
  switch (action.type) {
    case types.GET_PLAN:
      return { loading: true, ...state };
    case types.GET_PLAN_SUCCESS:
      return { loading: false, response };
    case types.GET_PLAN_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

function editPlanReducer(state = [], action) {
  const response = action.response;
  switch (action.type) {
    case types.EDIT_PLAN:
      return { loading: true, ...state };
    case types.EDIT_PLAN_SUCCESS:
      return { loading: false, response };
    case types.EDIT_PLAN_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

function deletePlanReducer(state = [], action) {
  const response = action.response;
  switch (action.type) {
    case types.DELETE_PLAN:
      return { loading: true, ...state };
    case types.DELETE_PLAN_SUCCESS:
      return { loading: false, response };
    case types.DELETE_PLAN_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

export default combineReducers({
  createPlan: createPlanReducer,
  getPlan: getPlanReducer,
  editPlan: editPlanReducer,
  deletePlan: deletePlanReducer,
});
