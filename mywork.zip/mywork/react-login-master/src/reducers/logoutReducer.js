import * as types from "../actions";

export default function(state = [], action) {
  const response = action.response;
  switch (action.type) {
    case types.LOGOUT_USER:
      return { loading: true, ...state };
    case types.LOGOUT_USER_SUCCESS:
      return { loading: false, response };
    case types.LOGOUT_USER_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

