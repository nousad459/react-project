import * as types from "../actions";

export default function(state = [], action) {
  const response = action.response;

  switch (action.type) {
    case types.REFRESH_TOKEN:
      return { loading: true, ...state };
    case types.REFRESH_TOKEN_SUCCESS:
      return { loading: false, response };
    case types.REFRESH_TOKEN_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}