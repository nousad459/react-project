import * as types from "../actions";

export default function(state = 0, action) {
  // console.log(">", state);
  //   const response = action.response;
  switch (action.type) {
    case types.INCREMENT:
      return (state = state + 1);
    default:
      return state;
  }
}
