import * as types from "../actions";
import { combineReducers } from "redux";

function getCountryReducer(state = [], action) {
  let response = action.response;
  switch (action.type) {
    case types.GET_COUNTRY:
      return { loading: true, ...state };
    case types.GET_COUNTRY_SUCCESS:
      return { loading: false, response };
    case types.GET_COUNTRY_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

function getStateReducer(state = [], action) {
  const response = action.response;
  switch (action.type) {
    case types.GET_STATES:
      return { loading: true, ...state };
    case types.GET_STATES_SUCCESS:
      return { loading: false, response };
    case types.GET_STATES_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

function getCityReducer(state = [], action) {
  const response = action.response;
  switch (action.type) {
    case types.GET_CITY:
      return { loading: true, ...state };
    case types.GET_CITY_SUCCESS:
      return { loading: false, response };
    case types.GET_CITY_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}



export default combineReducers({
  country: getCountryReducer,
  states: getStateReducer,
  city: getCityReducer,
  
});
