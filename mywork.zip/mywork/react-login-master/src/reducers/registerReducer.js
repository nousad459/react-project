import * as types from '../actions';

export default function(state = [], action) {
  let response = action.response;
  switch (action.type) {
    case types.REGISTER_USER:
      return { loading: true, ...state };
    case types.REGISTER_USER_SUCCESS:
      return { loading: false, response };
    case types.REGISTER_USER_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}