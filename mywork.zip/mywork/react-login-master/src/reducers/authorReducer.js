import * as types from '../actions';

export default function(state = [], action) {
  let response = action.response;
  switch (action.type) {
    case types.GET_AUTHOR:
      return { loading: true, ...state };
    case types.GET_AUTHOR_SUCCESS:
      return { loading: false, response };
    case types.GET_AUTHOR_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}