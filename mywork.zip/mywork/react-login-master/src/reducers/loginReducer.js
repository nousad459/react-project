import * as types from "../actions";

export default function(state = [], action) {
  const response = action.response;
  // console.log(">>>>>>", action);
  //  debugger
  switch (action.type) {
    case types.LOGIN_USER:
      return { loading: true, ...state };
    case types.LOGIN_USER_SUCCESS:
      return { loading: false, response };
    case types.LOGIN_USER_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

// import * as types from '../actions';
// import { combineReducers } from 'redux';

// function userRegistrationReducer(state = [], action) {
//   let response = action.response;
//   switch (action.type) {
//     case types.REGISTER_USER:
//       return { loading: true, ...state };
//     case types.REGISTER_USER_SUCCESS:
//       return { loading: false, response };
//     case types.REGISTER_USER_ERROR:
//       return { loading: false, response };
//     default:
//       return state;
//   }
// }

// function userLoginReducer(state = [], action) {
//   const response = action.response;
//   switch (action.type) {
//     case types.LOGIN_USER:
//       return { loading: true, ...state };
//     case types.LOGIN_USER_SUCCESS:
//       return {loading: true, response };
//     case types.LOGIN_USER_ERROR:
//       return { loading: true, response };
//     default:
//       return state;
//   }
// };

// export default combineReducers({
//   registration: userRegistrationReducer,
//   login: userLoginReducer,
// })
