import { combineReducers } from "redux";
import register from "./registerReducer";
import login from "./loginReducer";
import author from "./authorReducer";
import plan from "./planReducer";
import logout from "./logoutReducer";
import increment from "./incrementReducer";
import address from "./addressReducer";
import refreshToken from "./refreshTokenReducer";

const rootReducer = combineReducers({
  register,
  login,
  author,
  plan,
  logout,
  increment,
  address,
  refreshToken
});

export default rootReducer;
