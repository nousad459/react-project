import { put, call } from "redux-saga/effects";
import {
  createPlanService,
  getPlanService,
  editPlanService,
  deletePlanService
} from "../services/takePlanServices";
import * as types from "../actions";

export function* createPlanSaga(payload) {
  try {
    const response = yield call(createPlanService,payload.payload);
    yield put({ type: types.CREATE_PLAN_SUCCESS, response});
  } catch (error) {
    if(error.response){
    yield put({ type: types.CREATE_PLAN_ERROR, response:error.response.data});
    }else{
      yield put({ type: types.CREATE_PLAN_ERROR, response:{error:"Error"}});
    }
  }
 
}

export function* getPlanSaga(payload) {
    try {
      const response = yield call(getPlanService,payload.payload);
      yield put({ type: types.GET_PLAN_SUCCESS, response});
    } catch (error) {
      if(error.response){
      yield put({ type: types.GET_PLAN_ERROR, response:error.response.data});
      }else{
        yield put({ type: types.GET_PLAN_ERROR, response:{error:"Error"}});
      }
    }
   
  }
  
  export function* editPlanSaga(payload) {
    try {
      const response = yield call(editPlanService,payload.payload);
      yield put({ type: types.EDIT_PLAN_SUCCESS, response});
    } catch (error) {
      if(error.response){
      yield put({ type: types.EDIT_PLAN_ERROR, response:error.response.data});
      }else{
        yield put({ type: types.EDIT_PLAN_ERROR, response:{error:"Error"}});
      }
    }
   
  }

  export function* deletePlanSaga(payload) {
    try {
      const response = yield call(deletePlanService,payload.payload);
      yield put({ type: types.DELETE_PLAN_SUCCESS, response});
    } catch (error) {
      if(error.response){
      yield put({ type: types.DELETE_PLAN_ERROR, response:error.response.data});
      }else{
        yield put({ type: types.DELETE_PLAN_ERROR, response:{error:"Error"}});
      }
    }
   
  }
  
  
  
