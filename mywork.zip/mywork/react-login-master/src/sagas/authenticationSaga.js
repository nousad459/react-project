import { put, call } from "redux-saga/effects";
import {
  registerUserService,
  loginUserService,
  logoutService,
  refreshTokenService
} from "../services/authenticationService";
import * as types from "../actions";

export function* registerSaga(payload) {
  try {
    const response = yield call(registerUserService, payload);
    console.log("responce is",JSON.stringify(response))
    yield put({ type: types.REGISTER_USER_SUCCESS, response});
  } catch (error) {
    if(error.response){
    yield put({ type: types.REGISTER_USER_ERROR, response:error.response.data});
    }else{
      yield put({ type: types.REGISTER_USER_ERROR, response:{error:"Error"}});
    }
  }
  // try {
  //   const response = yield call(registerUserService, payload);
  //   yield [put({ type: types.REGISTER_USER_SUCCESS, response })];
  // } catch (error) {
  //   yield put({ type: types.REGISTER_USER_ERROR, error });
  // }
}

export function* loginSaga(payload) {
  try {
    const response = yield call(loginUserService, payload);
    yield put({ type: types.LOGIN_USER_SUCCESS, response });
  } catch (error) {
    yield put({ type: types.LOGIN_USER_ERROR, error });
  }
}

export function* logoutSaga(payload) {
  try {
    const response = yield call(logoutService, payload);
    yield put({ type: types.LOGOUT_USER_SUCCESS, response });
  } catch (error) {
    yield put({ type: types.LOGOUT_USER_ERROR, error });
  }
}


export function* refreshTokenSaga(payload) {
  try {
    const response = yield call(refreshTokenService, payload);
    yield put({ type: types.REFRESH_TOKEN_SUCCESS, response });
  } catch (error) {
    yield put({ type: types.REFRESH_TOKEN_ERROR, error });
  }
}
