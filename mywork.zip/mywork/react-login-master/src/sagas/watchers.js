import { takeLatest } from "redux-saga/effects";
import { registerSaga, loginSaga, logoutSaga, refreshTokenSaga } from "./authenticationSaga";
import { authorSaga } from "./authorSaga";
import {
  createPlanSaga,
  getPlanSaga,
  editPlanSaga,
  deletePlanSaga,
} from "./takePlanSaga";
import * as addressSaga from "./addressSaga";

import * as types from "../actions";

export default function* watchUserAuthentication() {
  yield takeLatest(types.REGISTER_USER, registerSaga);
  yield takeLatest(types.LOGIN_USER, loginSaga);
  yield takeLatest(types.GET_AUTHOR, authorSaga);
  yield takeLatest(types.CREAT_PLAN, createPlanSaga);
  yield takeLatest(types.GET_PLAN, getPlanSaga);
  yield takeLatest(types.EDIT_PLAN, editPlanSaga);
  yield takeLatest(types.DELETE_PLAN, deletePlanSaga);
  yield takeLatest(types.LOGOUT_USER, logoutSaga);
  yield takeLatest(types.GET_COUNTRY, addressSaga.getCountrySaga);
  yield takeLatest(types.GET_STATES, addressSaga.getStatesSaga);
  yield takeLatest(types.GET_CITY, addressSaga.getCitySaga);
  yield takeLatest(types.REFRESH_TOKEN, refreshTokenSaga);
}
