import { put, call } from "redux-saga/effects";
import * as addressService from "../services/addressServices";
import * as types from "../actions";

export function* getCountrySaga() {
  try {
    const response = yield call(addressService.getCountryService);
    yield put({ type: types.GET_COUNTRY_SUCCESS, response});
  } catch (error) {
    if(error.response){
    yield put({ type: types.GET_COUNTRY_ERROR, response:error.response.data});
    }else{
      yield put({ type: types.GET_COUNTRY_ERROR, response:{error:"Error"}});
    }
  }
 
}

export function* getStatesSaga(payload) {
    try {
      const response = yield call(addressService.getStatesService,payload.payload);
      yield put({ type: types.GET_STATES_SUCCESS, response});
    } catch (error) {
      if(error.response){
      yield put({ type: types.GET_STATES_ERROR, response:error.response.data});
      }else{
        yield put({ type: types.GET_STATES_ERROR, response:{error:"Error"}});
      }
    }
   
  }
  
  export function* getCitySaga(payload) {
    try {
      const response = yield call(addressService.getCityService,payload.payload);
      yield put({ type: types.GET_CITY_SUCCESS, response});
    } catch (error) {
      if(error.response){
      yield put({ type: types.GET_CITY_ERROR, response:error.response.data});
      }else{
        yield put({ type: types.GET_CITY_ERROR, response:{error:"Error"}});
      }
    }
   
  }


  
  
