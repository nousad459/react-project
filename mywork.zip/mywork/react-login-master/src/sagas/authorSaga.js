import { put, call } from "redux-saga/effects";
import {
  getAuthorService,
} from "../services/authoServices";
import * as types from "../actions";

export function* authorSaga(payload) {
  try {
    const response = yield call(getAuthorService,payload.payload);
    yield put({ type: types.GET_AUTHOR_SUCCESS, response});
  } catch (error) {
    if(error.response){
    yield put({ type: types.GET_AUTHOR_ERROR, response:error.response.data});
    }else{
      yield put({ type: types.GET_AUTHOR_ERROR, response:{error:"Error"}});
    }
  }
 
}

