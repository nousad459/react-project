import * as types from './index';


export const getCountryAction = () => {
  return {
    type: types.GET_COUNTRY,
  };
};
  

export const getStatesAction = (payload) => {
  return {
    type: types.GET_STATES,
    payload
  }
};

export const getCityAction = (payload) => {
  return {
    type: types.GET_CITY,
    payload
  }
};
