import * as types from './index';

export const getAuthorAction = (payload) => {
  return {
    type: types.GET_AUTHOR,
    payload
  }
};
