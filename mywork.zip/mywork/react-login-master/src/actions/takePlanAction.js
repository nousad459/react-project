import * as types from './index';


export const createPlanAction = (payload) => {
    return {
      type: types.CREAT_PLAN,
      payload
    }
  };
  

export const getPlanAction = (payload) => {
  return {
    type: types.GET_PLAN,
    payload
  }
};

export const editPlanAction = (payload) => {
  return {
    type: types.EDIT_PLAN,
    payload
  }
};

export const deletePlanAction = (payload) => {
  return {
    type: types.DELETE_PLAN,
    payload
  }
};

