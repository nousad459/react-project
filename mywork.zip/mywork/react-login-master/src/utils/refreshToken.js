import * as api from "../utils/api";

export const refreshToken = async () => {
    const payload = {
        user_id: 17
    }
   
    try {
        let response = await api.post("api/refreshToken",payload);
        // debugger
        return response;
      } catch (error) {
        return error;
      }

  };