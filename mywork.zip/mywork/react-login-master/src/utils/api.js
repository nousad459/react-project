import axios from "axios";
// import { PART_SENTRY, DEPLOY_PLATFORM } from "./config";
import { message } from "antd";
import { checkCookie } from "./cookies";

axios.defaults.baseURL =  "http://localhost:4200/";//  DEPLOY_PLATFORM;
axios.defaults.headers.common["Cache-Control"] = "no-cache";
axios.defaults.headers.common["Pragma"] = "no-cache";
axios.defaults.headers.common["Expires"] = -1;


axios.interceptors.request.use(
  (config) => {
    const token = checkCookie();
    if (token !== null) {
      config.headers["Authorization"] = "Bearer " + token;
      return config;
    } else {
      return config;
    }
  },
  (error) => {
    Promise.reject(error);
  }
);

export const setAuthToken = (token) => {
  axios.defaults.headers.common["X-Auth-Token"] = token;
};


export const get = async (url, config) => {
  return (await axios.get(url, config)).data;
};


export const getBlob = async (url, config = {}) => {
  config.responseType = "blob";
  return await axios.get(url, config);
};

export const getImageBase64 = async (url) => {
  return await axios
    .get(url, { responseType: "arrayBuffer" })
    .then(
      (response) =>
        `data:${response.headers["content-type"]};base64,${btoa(
          String.fromCharCode(...new Uint8Array(response.data))
        )}`
    )
    .catch((error) => {
      console.log("getImageBase64 failed", error);

      return null;
    });
};

export const post = async (url, data) => {
  return (await axios.post(url, data)).data;
};

export const postFile = async (url, data) => {
  return (
    await axios.post(url, data, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    })
  ).data;
};

export const put = async (url, data) => {
  return (await axios.put(url, data)).data;
};

export const deleteRec = async (url, data) => {
  console.log(">>>>>",data)
  return (await axios.delete(url, data)).data;
};

export const deleteRecWithData = async (url, data) => {
  return (await axios({ method: "delete", url: url, data: data })).data;
};

export const generateApiParameters = (pagination, filters, sorter) => {
  let params = {
    limit: pagination.pageSize,
    offset: (pagination.current - 1) * pagination.pageSize,
    sort:
      sorter.field &&
      `${sorter.order === "descend" ? "-" : "+"}${sorter.field}`,
  };
  Object.keys(filters).forEach((item) => {
    if (filters[item]) {
      params[item] = filters[item][0];
    }
  });
  return params;
};

export const refreshTokenApi = async (url, data) => {
  console.log("fgg", url);
  return (await axios.post(url, data)).data;
};

// Interceptor Functions

export const passThroughResponse = (response) => response;

export const handleRequestError = (error) => {
  return Promise.reject(error);
};

// This will handle API errors that return an error in the format:

export const handleSimpleApiError = (error, intl) => {
  // console.log("error", error.errors[0].response.response.status);
  // console.log("error", error);
  const { response } = error.errors[0];
  if (!response) {
    console.error(error);
    message.error("Server Error");
  } else {
    if (response.response.data && response.response.data.error) {
      if (typeof error.errors[0].response.response.data.error === "object") {
        message.error(error.errors[0].response.response.data.message);
      } else {
        message.error(error.errors[0].response.response.data.error);
      }
    } else {
      message.error(error.errors[0].response.response.data.message);
    }
  }
};
