import * as api from "../utils/api";

/*Service for fetch order place data */
export const createPlanService = async (payload) => {
  try {
    let response = await api.post("api/takePlan", payload);
    return response;
  } catch (error) {
    return error;
  }
};

/*Service for fetch order place data */
export const getPlanService = async (payload) => {
  try {
    let response = await api.get("api/getPlan?user_id=" + payload.user_id);
    return response;
  } catch (error) {
    return error;
  }
};

/*Service for edit plan*/
export const editPlanService = async (payload) => {
  try {
    let response = await api.post("api/updatePlanType",payload);
    return response;
  } catch (error) {
    return error;
  }
};

/*Service for delete plan*/
export const deletePlanService = async (payload) => {
  try {
    let response = await api.deleteRecWithData("api/deletePlan",payload);
    return response;
  } catch (error) {
    return error;
  }
};
