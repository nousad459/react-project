import { setCookie } from "../utils/cookies";
import * as api from "../utils/api";


export const registerUserService = (request) => {
  const REGISTER_API_ENDPOINT = "https://reqres.in/api/register";

  const parameters = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(request.user),
  };

  return fetch(REGISTER_API_ENDPOINT, parameters)
    .then((response) => {
      if (!response.ok) {
        //throw Error(response.json());
        return response.json();
      }
      return response.json();
    })
    .then((res) => {
      if (res.error === "Note: Only defined users succeed registration") {
        return { success: false, message: res.error, response: res };
      }

      return {
        success: true,
        message: "Registration Successful",
        response: res,
      };
    })
    .catch((error) => {
      return {
        success: false,
        message: "Registration failed due to api problem",
        response: error,
      };
    });
};

export const loginUserService = (request) => {
  const LOGIN_API_ENDPOINT = "http://localhost:4200/api/userLogin";

  const parameters = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(request.user),
  };

  return fetch(LOGIN_API_ENDPOINT, parameters)
    .then((response) => {
      if (!response.ok) {
        //throw Error(response.json());
        return response.json();
      }
      return response.json();
    })
    .then((res) => {
      if (res.error === "user not found") {
        return { success: false, message: res.error, response: res };
      } else {
         console.log("res",res)
        //  setCookie("token", res.result.access_token, 1);
      }

      return { success: true, message: "Login Successful", response: res };
    })
    .catch((error) => {
      return {
        success: false,
        message: "login failed due to api problem",
        response: error,
      };
    });
};




/*Service for fetch order place data */
export const logoutService = async (payload) => {
    try {
      let response = await api.post("api/logout",payload.user);
      return response;
    } catch (error) {
      return error;
    }
  };
  

  
/*Service for refresh token service */
export const refreshTokenService = async (payload) => {
  try {
    let response = await api.post("api/refreshToken",payload.userId);
    return response;
  } catch (error) {
    return error;
  }
};
