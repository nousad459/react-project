import * as api from "../utils/api";

/*Service for fetch order place data */
export const getCountryService = async () => {
  try {
    let response = await api.get("api/getCountries");
    return response;
  } catch (error) {
    return error;
  }
};

/*Service for fetch order place data */
export const getStatesService = async (payload) => {
  // debugger
  try {
    let response = await api.get("api/getStates/" + payload);
    return response;
  } catch (error) {
    return error;
  }
};

/*Service for edit plan*/
export const getCityService = async (payload) => {
  try {
    let response = await api.get("api/getCities/" + payload);
    return response;
  } catch (error) {
    return error;
  }
};
