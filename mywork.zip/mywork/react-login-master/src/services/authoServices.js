import * as api from "../utils/api";


/*Service for fetch order place data */
export const getAuthorService = async (payload) => {
    try {
      let response = await api.get("api/authorPagination?page="+payload.page+"&limit="+payload.limit);
      return response;
    } catch (error) {
      return error;
    }
  };
  