import React, { Component } from "react";
import { Layout, Menu, Button, Popconfirm, message } from "antd";
import { Link } from "react-router-dom";
import { LoginOutlined } from "@ant-design/icons";
import { connect } from "react-redux";
import { getAuthorAction } from "../actions/authorAction";
import { setCookie } from "../utils/cookies";
import { Table, Avatar, Pagination } from "antd";
import "./App.css";
const { Header } = Layout;
const columns = [
  {
    title: "Id",
    dataIndex: "id",
    key: "id",
  },
  {
    title: "First Name",
    dataIndex: "first_name",
    key: "first_name",
  },
  {
    title: "Last Name",
    dataIndex: "last_name",
    key: "last_name",
  },
  {
    title: "Email",
    dataIndex: "email",
    key: "email",
  },
  {
    title: "Profile",
    dataIndex: "avatar",
    key: "avatar",
    render: (url) => <Avatar src={url} />,
  },
];
class Authors extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      value: "",
      totalPage: 1,
    };
  }

  componentDidMount() {
    const parameter = {
      page: 1,
      limit: 10,
    };
    this.props.getAuthorAction(parameter);
  }

  onChange = (pageNumber, pageSize) => {
    console.log("page", pageSize + "" + pageNumber);
    // this.fetchData(pageNumber);
    const parameter = {
      page: pageNumber === 0 ? pageNumber + 1 : pageNumber,
      limit: pageSize,
    };
    this.props.getAuthorAction(parameter);
  };

  onShowSizeChange = (current, pageSize) => {
    console.log(current, pageSize);
    const parameter = {
      page: current === 0 ? current + 1 : current,
      limit: pageSize,
    };
    this.props.getAuthorAction(parameter);
  };

  searchValue = (e) => {
    this.setState({ value: e.target.value });
  };
  logout = () => {
    if (window.confirm("Are you want to logout?")) {
      setCookie("auth_token", "", 1);
      window.location.href = "/";
    }
  };
  render() {
    const { location } = this.props;
    const { response, loading } = this.props.author;
    return (
      <div className="App">
        <div style={{ padding: "50px 50px" }}>
          <div style={{ float: "left" }}>
            Search
            <input type="text" onChange={(e) => this.searchValue(e)} />
            <button>Show</button>
          </div>
          <br /> <br />
          <Table
            columns={columns}
            dataSource={
              loading === false && response.Message === "Success"
                ? response.result.filter(
                    (data) =>
                      !this.state.value ||
                      data.first_name.toLowerCase() ===
                        this.state.value.toLowerCase() ||
                      data.id === parseInt(this.state.value) ||
                      data.first_name.toLowerCase().includes(this.state.value)
                  )
                : ""
            }
            loading={loading === false ? false : true}
            pagination={false}
          />
          <br />
          <div style={{ float: "left" }}>
            <Pagination
              defaultCurrent={loading === false ? 1 : ""}
              total={loading === false ? response.Total : ""}
              onChange={this.onChange}
              // onShowSizeChange={this.onShowSizeChange}
              // defaultPageSize={20}
            />
          </div>
          {/* <button>Ok</button> */}
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({ author: state.author });
const mapDispatchToProps = {
  getAuthorAction: getAuthorAction,
};

export default connect(mapStateToProps, mapDispatchToProps)(Authors);
