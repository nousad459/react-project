import React, { Component } from "react";
import { Redirect ,Link } from "react-router-dom";
import { connect } from "react-redux";

import "./login.css";
import { loginUserAction } from "../actions/authenticationActions";
import { setCookie } from "../utils/cookies";

class LoginPage extends Component {
  onHandleLogin = (event) => {
    event.preventDefault();

    let email = event.target.email.value;
    let password = event.target.password.value;

    const data = {
      email,
      password,
    };

    this.props.dispatch(loginUserAction(data));
  };

  componentDidMount() {
    document.title = "React Login";
  }

  componentDidUpdate(prevProps) {
    if (prevProps.login !== this.props.login) {
      if (
        this.props.login.loading === false &&
        this.props.login.response.response.success === true
      ) {
        // debugger
        setCookie(
          "auth_token",
          this.props.login.response.response.result.access_token,
          1
        );
        localStorage.setItem(
          "user",
          JSON.stringify(this.props.login.response.response.result)
        );
      }
    }
  }

  render() {
    let isSuccess, message;

    // if (this.props.login.response.hasOwnProperty("response")) {
    isSuccess = this.props.login.response
      ? this.props.login.response.response.success
      : "";
    message = this.props.login.response
      ? this.props.login.response.response.message
      : "";

    // if (isSuccess) {
    // setCookie(
    //   "token",
    //   this.props.response.login.response.response.token,
    //   1
    // );
    // }
    // }
    console.log(">>>>>", this.props.login);
    return (
      <div className="container">
        <div class="wrapper">
          <div class="title">Login Form</div>
          {!isSuccess ? <div>{message}</div> : ""}
          {/* <Redirect to="/dashboard" /> */}
          <form onSubmit={this.onHandleLogin}>
            <div class="field">
              <input type="text" name="email" id="email" required />
              <label>Email Address</label>
            </div>
            <div class="field">
              <input type="password" name="password" id="password" required />
              <label>Password</label>
            </div>
            <div class="content">
              <div class="checkbox">
                <input type="checkbox" id="remember-me" />
                <label for="remember-me">Remember me</label>
              </div>
              <div class="pass-link">
                <a href="#">Forgot password?</a>
              </div>
            </div>
            <div class="field">
              <input type="submit" value="Login" />
            </div>
            <div class="signup-link">
              Not a member? <Link to="/register">Signup now</Link>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (response) => ({ login: response.login });

export default connect(mapStateToProps)(LoginPage);
