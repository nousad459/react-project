import React, { Component } from "react";
import { Modal, Form, Button, Input, message, Row, Col, Select } from "antd";
import { connect } from "react-redux";
import { getUserInfo } from "../../utils/cookies";
import {
  createPlanAction,
  getPlanAction,
  editPlanAction,
} from "../../actions/takePlanAction";

const { Option } = Select;
const planName = ["Silver", "Gold", "Diamond", "Star"];
const planType = ["Type1", "Type2", "Type"];

class CreateTakePlanModal extends Component {
  state = {
    number: 1,
    planName: "",
    planType: [],
    tempData: "",
    userId: getUserInfo(),
  };
  /*use for save data for shopping cart */
  onSubmit = () => {
    if (this.state.planName && this.state.planType) {
      const payload = {
        user_id: this.state.userId,
        plan_name: this.state.planName,
        plan_type: this.state.planTypeData,
      };
      this.props.createPlanAction(payload);
      message.success("Added Successfully", 0.5);
      //   this.props.getPlanAction({ user_id: 17 });
      //   this.props.onClose();
    } else {
      message.error("Quantity must be at least one");
    }
  };

  componentDidUpdate(prevProps) {
    if (
      prevProps.createPlanData.createPlan !==
      this.props.createPlanData.createPlan
    ) {
      if (this.props.createPlanData.createPlan.loading === false) {
        this.props.getPlanAction({ user_id: this.state.userId });
        this.props.onClose();
      }
      //   message.success("Added Successfully", 0.5);
      //   this.props.requestShoppingCart();
    }

    if (prevProps.editData.editPlan !== this.props.editData.editPlan) {
      if (this.props.editData.editPlan.loading === false) {
        this.props.getPlanAction({ user_id: this.state.userId });
        this.setState({tempData:""})
        this.props.onClose();
        message.success("Updated Successfully", 0.5);
      }
    }
    if (
      prevProps.records !== this.props.records ||
      prevProps.mode !== this.props.mode ||
      prevProps.time !== this.props.time
    ) {
      // console.log(">>>");
      if (this.props.mode === "Edit") {
        let planTypes = this.props.records.planTypes.map(
          (data) => data.planType
        );

        this.setState({
          planName: this.props.records.planName,
          planTypeData: planTypes,
        });
      }
      if (this.props.mode === "Add") {
        this.setState({
          planName: "",
          planTypeData: [],
        });
      }
    }
  }
  edit = () => {
    const payload = {
      plan_name: this.props.records.planName,
      plan_type: this.state.planTypeData.slice(-1)[0],
      tempData: this.state.tempData,
      user_id: this.state.userId,
    };
    this.props.editPlanAction(payload);
  };

  handlePlanName = (val) => {
    this.setState({ planName: val });
  };

  editPlanOnChange = (data) => {
    const payload = {
      plan_name: this.props.records.planName,
      plan_type: data.slice(-1)[0],
      tempData: this.state.tempData,
    };
    this.props.editPlanAction(payload);
  };
  handlePlanType = (val) => {
    if (this.props.mode === "Edit") {
      var res = this.props.records.planTypes.filter(function(n) {
        return !this.has(n.planType);
      }, new Set(val));
      console.log(">>>>", res);
      this.setState({ planTypeData: val, tempData: res });
    } else {
      this.setState({ planTypeData: val });
    }
  };
  render() {
    const { show, title, onClose, mode } = this.props;
    // console.log(">>>>>", this.props);
    // const { userId, planName, planType } = this.props.records;
    return (
      <>
        <Modal
          title={title}
          visible={show}
          onCancel={() => {
            onClose();
            this.setState({ planName: "", planTypeData: [], tempData: "" });
          }}
          //   footer={null}
          width={400}
          onOk={mode === "Add" ? this.onSubmit : this.edit}
          okText={mode === "Add" ? "Save" : "Edit"}
          okButtonProps={
            mode === "Edit"
              ? !this.state.tempData
                ? { disabled: true }
                : ""
              : { disabled: false }
          }
          // cancelButtonProps={}
          // cancelText={"CC"}
        >
          <div className="cardBox">
            <Form
              layout="vertical"
              name="form_in_modal"
              initialValues={{ modifier: "public" }}
              //   onFinish={this.onSubmit}
            >
              <Row>
                <Col className="itemText" xs={12} sm={12} md={12} lg={12}>
                  <strong>User Id:</strong>
                </Col>
                <Col className="itemVal" xs={12} sm={12} md={12} lg={12}>
                  <Input
                    value={
                      Object.keys(this.props.records).length === 0 &&
                      this.props.records.constructor === Object
                        ? this.props.userId
                        : this.props.records.userId
                    }
                    disabled
                  />
                </Col>
              </Row>
              <Row>
                <Col className="itemText" xs={12} sm={12} md={12} lg={12}>
                  <strong>Plan Name:</strong>
                </Col>
                <Col className="itemVal" xs={12} sm={12} md={12} lg={12}>
                  <Select
                    showArrow={true}
                    style={{ width: "100%" }}
                    placeholder="Select Plan Name"
                    optionLabelProp="label"
                    onChange={(val) => this.handlePlanName(val)}
                    value={this.state.planName}
                  >
                    {planName
                      ? planName.map((data, index) => {
                          return <Option value={data}>{data}</Option>;
                        })
                      : ""}
                  </Select>
                </Col>
              </Row>

              <Row>
                <Col className="itemText" xs={12} sm={12} md={12} lg={12}>
                  <strong>Plan Type:</strong>
                </Col>
                <Col className="itemVal" xs={12} sm={12} md={12} lg={12}>
                  <Select
                    mode="tags"
                    style={{ width: "100%" }}
                    placeholder="Select Plan Type"
                    value={this.state.planTypeData}
                    onChange={(val) => this.handlePlanType(val)}
                    optionLabelProp="label"
                  >
                    {planType.map((data, index) => {
                      return <Option value={data}>{data}</Option>;
                    })}
                  </Select>
                </Col>
              </Row>

              {/* <Form.Item>
                <Button type="primary" htmlType="submit">
                  Add To Cart
                </Button>
              </Form.Item> */}
            </Form>
          </div>
        </Modal>
      </>
    );
  }
}
const mapStateToProps = (state) => ({
  createPlanData: state.plan,
  editData: state.plan,
});
const mapDispatchToProps = {
  createPlanAction: createPlanAction,
  getPlanAction: getPlanAction,
  editPlanAction: editPlanAction,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CreateTakePlanModal);
