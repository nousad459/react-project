import React, { Component } from "react";
import { Layout, Menu, Button, Popconfirm, message } from "antd";
import { Link } from "react-router-dom";
import { LoginOutlined } from "@ant-design/icons";
import { setCookie } from "../utils/cookies";
import { Table, Avatar, Pagination } from "antd";
import axios from "axios";
import "./App.css";
const { Header } = Layout;
const columns = [
  {
    title: "Id",
    dataIndex: "id",
    key: "id",
  },
  {
    title: "First Name",
    dataIndex: "first_name",
    key: "first_name",
  },
  {
    title: "Last Name",
    dataIndex: "last_name",
    key: "last_name",
  },
  {
    title: "Email",
    dataIndex: "email",
    key: "email",
  },
  {
    title: "Profile",
    dataIndex: "avatar",
    key: "avatar",
    render: (url) => <Avatar src={url} />,
  },
];
class AboutUs extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      value: "",
      totalPage: 1,
    };
  }

  componentDidMount() {
    this.fetchData(1);
    // debugger
    const data = this.fetchData2(1);
//     const dd =  data.then((dd)=>{
// debugger
//        return dd.data;
//     })
//     .then((data)=>{
//       // console.log(">>>", data);
//       return data
//     });
    console.log(">>>", data);
  }

  onChange = (pageNumber) => {
    this.fetchData(pageNumber);
  };
  fetchData = async (pageNumber) => {
    try {
      await fetch("https://reqres.in/api/users?page=" + pageNumber)
        .then((res) => {
          return res.json();
        })
        .then((res) => {
          this.setState({ data: res.data, totalPage: res.total });
        });
    } catch (error) {
      return error;
    }
  };

  
  // fetchData2 = async (pageNumber) => {
  //   try {
  //     // const data =[];
  //     return axios("https://reqres.in/api/users?page=" + pageNumber);
  //   } catch (error) {
  //     return error;
  //   }
  // };

  fetchData2 = async (pageNumber, data) => {
    debugger
    return (await axios.get("https://reqres.in/api/users?page=" + pageNumber, data)).data;
  };


  searchValue = (e) => {
    this.setState({ value: e.target.value });
  };
  logout = () => {
    if (window.confirm("Are you want to logout?")) {
      setCookie("token", "", 1);
      window.location.href = "/";
    }
  };
  render() {
    const { location } = this.props;
    return (
      <div className="App">
        {/* <Header>
          <div className="logo" />
          <Menu
            theme="dark"
            mode="horizontal"
            defaultSelectedKeys={["Information"]}
            selectedKeys={[location.pathname]}
          >
            <Menu.Item key="/dashboard">
              <Link
                to={{
                  pathname: "/dashboard",
                }}
              >
                Home
              </Link>
            </Menu.Item>
            <Menu.Item key="/epc">
              <Link
                to={{
                  pathname: "/epc",
                }}
              >
                EPC
              </Link>
            </Menu.Item>
            <Menu.Item key="/contact-us">
              <Link
                to={{
                  pathname: "/contact-us",
                }}
              >
                Contact Us
              </Link>
            </Menu.Item>

            <Button
              onClick={this.logout}
              style={{ float: "right", marginTop: "20px" }}
            >
              <LoginOutlined />
            </Button>
          </Menu>
        </Header> */}

        <div style={{ padding: "50px 50px" }}>
          <div style={{float:"left"}}>
            Search
            <input type="text" onChange={(e) => this.searchValue(e)} />
            <button>Show</button>
          </div>
          {/* <table>
            <tr>
              <td>Id</td>
              <td>First Name</td>
              <td>Last Name</td>
              <td>Email</td>
            </tr>

            {this.state.data
              .filter(
                (data) =>
                  !this.state.value ||
                  data.first_name.toLowerCase() === this.state.value ||
                  data.id === parseInt(this.state.value)||
                  data.first_name.toLowerCase().includes(this.state.value)
              )
              .map((data, i) => {
                return (
                  <tr key={i}>
                    <td>{data.id}</td>
                    <td>{data.first_name}</td>
                    <td>{data.last_name}</td>
                    <td>{data.email}</td>
                  </tr>
                );
              })}
          </table> */}
          <br /> <br />
          <Table
            columns={columns}
            dataSource={
              this.state.data
                ? this.state.data.filter(
                    (data) =>
                      !this.state.value ||
                      data.first_name.toLowerCase() ===
                        this.state.value.toLowerCase() ||
                      data.id === parseInt(this.state.value) ||
                      data.first_name.toLowerCase().includes(this.state.value)
                  )
                : ""
            }
            pagination={false}
          />
          <br />
          <div style={{float:"left"}}>
             <Pagination
            defaultCurrent={1}
            total={this.state.totalPage}
            onChange={this.onChange}
          />
          </div>
         
          {/* <button>Ok</button> */}
        </div>
      </div>
    );
  }
}

export default AboutUs;
