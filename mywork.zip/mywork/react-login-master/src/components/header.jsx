import React from "react";
import { Button, Layout, Menu } from "antd";
import { connect } from "react-redux";
import { compose } from "redux";
// import { connect } from "react-redux";
import { Link, withRouter } from "react-router-dom";
import { setCookie,getUserInfo } from "../utils/cookies";
import { LoginOutlined } from "@ant-design/icons";
import { logoutUserAction } from "../actions/authenticationActions";
const { Header } = Layout;

class HeaderComponent extends React.Component {
  logout = () => {
    if (window.confirm("Are you want to logout?")) {
      // setCookie("auth_token", "", 1);
      // window.location.href = "/";
      this.props.logoutUserAction({ userId: getUserInfo() });
    }
  };

  componentDidUpdate(prevProps) {
    if (prevProps.logout !== this.props.logout) {
      if (this.props.logout.loading === false) {
        setCookie("auth_token", "", 1);
        localStorage.removeItem("user");
        window.location.href = "/";
      }
    }
  }
  render() {
    const { location } = this.props;
    console.log(">>>>>>", this.props.logout);
    return (
      <Layout className="layout">
        <Header>
          <div className="logo" />
          <Menu
            theme="dark"
            mode="horizontal"
            defaultSelectedKeys={["Information"]}
            selectedKeys={[location.pathname]}
          >
            <Menu.Item key="/">
              <Link
                to={{
                  pathname: "/",
                }}
              >
                Home
              </Link>
            </Menu.Item>
            <Menu.Item key="/epc">
              <Link
                to={{
                  pathname: "/epc",
                }}
              >
                EPC
              </Link>
            </Menu.Item>
            <Menu.Item key="/contact-us">
              <Link
                to={{
                  pathname: "/contact-us",
                }}
              >
                Contact Us
              </Link>
            </Menu.Item>
            <Menu.Item key="/authors">
              <Link
                to={{
                  pathname: "/authors",
                }}
              >
                Authors
              </Link>
            </Menu.Item>
            <Menu.Item key="/take-plan">
              <Link
                to={{
                  pathname: "/take-plan",
                }}
              >
                Take Plan
              </Link>
            </Menu.Item>
            <Menu.Item key="/search">
              <Link
                to={{
                  pathname: "/search",
                }}
              >
                Search
              </Link>
            </Menu.Item>
            <Menu.Item key="/multi-part">
              <Link
                to={{
                  pathname: "/multi-part",
                }}
              >
                MultiPartExample
              </Link>
            </Menu.Item>
            <Menu.Item key="/step">
              <Link
                to={{
                  pathname: "/step",
                }}
              >
                Step Example
              </Link>
            </Menu.Item>
            <Menu.Item key="/dropdown-multipart">
              <Link
                to={{
                  pathname: "/dropdown-multipart",
                }}
              >
                Dropdown MultiPart Example
              </Link>
            </Menu.Item>
            <Menu.Item key="/redux-hook">
              <Link
                to={{
                  pathname: "/redux-hook",
                }}
              >
                Redux Hook
              </Link>
            </Menu.Item>
            <Button
              onClick={this.logout}
              style={{ float: "right", marginTop: "20px" }}
            >
              <LoginOutlined />
            </Button>
          </Menu>
        </Header>
      </Layout>
    );
  }
}
const mapStateToProps = (state) => {
  return { logout: state.logout };
};

const mapDispatchToProps = {
  logoutUserAction: logoutUserAction,
};
// export default withRouter(HeaderComponent);

export default compose(
  withRouter,
  connect(mapStateToProps, mapDispatchToProps)
)(HeaderComponent);
