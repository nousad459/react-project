import React, { Component } from "react";
import { Layout, Menu, Button, Popconfirm, message } from "antd";
import { EditFilled, DeleteFilled } from "@ant-design/icons";
import { Link } from "react-router-dom";
import { LoginOutlined } from "@ant-design/icons";
import { setCookie } from "../utils/cookies";
import { connect } from "react-redux";
import { getPlanAction, deletePlanAction } from "../actions/takePlanAction";
import CreateTakePlanModal from "./modal/CreateTakePlanModal";
import { Table, Avatar, Pagination } from "antd";
import { getUserInfo } from "../utils/cookies";
import "./App.css";
import { bindActionCreators } from 'redux';
import * as actions from "../actions"
// import configureStore from '../store/configureStore';

// const store = configureStore();

class TakePlan extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      value: "",
      totalPage: 1,
      visible: false,
      mode: "Add",
      modalTitle: "",
      records: {},
      userId: getUserInfo(),
    };
    const { dispatch } = props;
 this.boundActions = bindActionCreators(actions, dispatch);
  }

  componentDidMount() {
    const userId = getUserInfo();
    this.props.getPlanAction({ user_id: userId });
  }

  edit = (records) => {
    this.setState({
      visible: true,
      modalTitle: "Edit Plan",
      records: records,
      mode: "Edit",
    });
  };
  deletePlan = (id, planName) => {
    const payload = {
      planId: id,
      planName: planName,
    };
    this.props.deletePlanAction(payload);
  };

  componentDidUpdate(prevProps) {
    if (prevProps.deleteDate !== this.props.deleteDate) {
      if (this.props.deleteDate.loading === false) {
        message.success("Deleted Successfully", 0.5);
        this.props.getPlanAction({ user_id: this.state.userId });
      }
    }
  }
  render() {
    // console.log(">>>>>", this.props.planData.getPlan);
    // console.log(">>>>>", this.props);
    const { response, loading } = this.props.planData.getPlan;
    const columns = [
      {
        title: "Use id",
        dataIndex: "userId",
        key: "userId",
      },
      {
        title: "Plan Name",
        dataIndex: "planName",
        key: "planName",
      },
      {
        title: "Plan Type",
        dataIndex: "planTypes",
        key: "planTypes",
        render: (planTypes, records) => (
          <span>
            {planTypes.map((data, i) => {
              return <div>{data.planType}</div>;
            })}
          </span>
        ),
      },
      {
        title: "Action",
        dataIndex: "planTypes",
        key: "Action",
        render: (planTypes, records) => (
          <span>
            {/* {console.log(">>>>", records)} */}
            <Button onClick={() => this.edit(records)}>
              <EditFilled />
            </Button>
            <Popconfirm
              title="Are you sure？"
              onConfirm={() =>
                this.deletePlan(records.takePlanId, records.planName)
              }
              okText="Yes"
              cancelText="No"
            >
              <Button danger>
                <DeleteFilled />
              </Button>
            </Popconfirm>
            ,
          </span>
        ),
      },
    ];
    let closeModal = () => this.setState({ visible: false });
    return (
      <div className="App">
        <CreateTakePlanModal
          title={this.state.modalTitle}
          show={this.state.visible}
          onClose={closeModal}
          records={this.state.records}
          mode={this.state.mode}
          time={new Date().getTime()}
          userId={this.state.userId}
        />
        <div style={{ padding: "50px 50px" }}>
          <div style={{ float: "left" }}>
            <Button
              type="primary"
              onClick={() =>
                this.setState({
                  visible: true,
                  modalTitle: "Create Plan",
                  mode: "Add",
                })
              }
            >
              Create Plan
            </Button>
          </div>
          <div style={{ float: "right" }}>
            Search
            <input type="text" onChange={(e) => this.searchValue(e)} />
            {/* <button >Show</button> */}
          </div>
          <br /> <br />
          <Table
            columns={columns}
            dataSource={
              loading === false && response.message === "Plan fetched"
                ? response.result.filter(
                    (data) =>
                      !this.state.value ||
                      data.first_name.toLowerCase() ===
                        this.state.value.toLowerCase() ||
                      data.id === parseInt(this.state.value) ||
                      data.first_name.toLowerCase().includes(this.state.value)
                  )
                : ""
            }
            loading={loading === false ? false : true}
            pagination={false}
          />
          <br />
          <div style={{ float: "left" }}>
            <Pagination
              defaultCurrent={1}
              total={this.state.totalPage}
              onChange={this.onChange}
            />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  planData: state.plan,
  deleteDate: state.plan.deletePlan,
});
const mapDispatchToProps = {
  getPlanAction: getPlanAction,
  deletePlanAction: deletePlanAction,
};

export default connect(mapStateToProps, mapDispatchToProps)(TakePlan);
