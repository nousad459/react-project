import React, { Component } from "react";
import { Layout, Menu, Button, Upload, message } from "antd";
import { LoginOutlined, UploadOutlined } from "@ant-design/icons";
import { setCookie, getCookie, checkCookie } from "../utils/cookies";
import { Redirect } from "react-router-dom";
import { Link } from "react-router-dom";
import readXlsxFile from "read-excel-file";
import Moment from "moment";
// import excelll from "../excelFile/ExcelExample.xlsx";
import excel from 'xlsx';
import "./App.css";
import { Select } from "antd";

const dummyRequest = ({ file, onSuccess }) => {
  setTimeout(() => {
    onSuccess("ok");
  }, 0);
};

const { Option } = Select;
const { Header } = Layout;

class ContactUs extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: "",
      selectedFile: null,
      selectedFileList: [],
    };
  }
  logout = () => {
    if (window.confirm("Are you want to logout?")) {
      setCookie("auth_token", "", 1);
      window.location.href = "/";
    }
  };

  searchValue = (e) => {
    this.setState({ value: e.target.value });
  };

  onChange = (info) => {
    console.log(">>>>>>>>>", info);
    readXlsxFile(info.fileList[0].originFileObj.name).then((rows) => {
      console.log(">>>>>", rows);
      // `rows` is an array of rows
      // each row being an array of cells.
    });
    const nextState = {};
    switch (info.file.status) {
      case "uploading":
        nextState.selectedFileList = [info.file];
        break;
      case "done":
        nextState.selectedFile = info.file;
        nextState.selectedFileList = [info.file];
        break;

      default:
        // error or removed
        nextState.selectedFile = null;
        nextState.selectedFileList = [];
    }
    this.setState(() => nextState);
  };

  // On file select (from the pop up) 
  onFileChange = event => { 
     
    // Update the state 
    // // this.setState({ selectedFile: event.target.files[0] }); 
    console.log(">>>>",event.target.files[0] )
    // // let fileName = "newData.xlsx";
    // let workbook = excel.readFile(event.target.files[0].name);
    // console.log(workbook)
    // readXlsxFile(event.target.files[0].name).then((rows) => {
    //   console.log(">>>>>", rows);
    //   // `rows` is an array of rows
    //   // each row being an array of cells.
    // });
   
  }; 
  render() {
    const { location } = this.props;
    const isCookie = getCookie("auth_token");
    //  console.log(">>>>.",checkCookie());
    // {isCookie ? "" : <Redirect to="/" />}
    console.log(">>>>.", this.state.selectedFile);
    const data = [
      {
        id: 0,
        email: "george.bluth@reqres.in",
        first_name: "Mark George",
        last_name: "Bluth",
        join_date: "2014/05/13 16:30:59",
      },
      {
        id: 1,
        email: "george.bluth@reqres.in",
        first_name: "George",
        last_name: "Bluth",
        join_date: "2014/05/13 16:30:59",
      },
      {
        id: 2,
        email: "janet.weaver@reqres.in",
        first_name: "Janet",
        last_name: "Weaver",
        join_date: "2014/05/13 16:30:59",
      },
      {
        id: 3,
        email: "emma.wong@reqres.in",
        first_name: "Emma",
        last_name: "Wong",
        join_date: "2014/05/13 16:30:59",
      },
      {
        id: 4,
        email: "eve.holt@reqres.in",
        first_name: "Eve",
        last_name: "Holt",
        join_date: "2014/05/13 16:30:59",
      },
      {
        id: 5,
        email: "charles.morris@reqres.in",
        first_name: "Charles",
        last_name: "Morris",
        join_date: "2014/05/13 16:30:59",
      },
      {
        id: 6,
        email: "tracey.ramos@reqres.in",
        first_name: "Tracey",
        last_name: "Ramos",
        join_date: "2014/05/13 16:30:59",
      },
    ];

    let dd = data.map((data) => ({
      ...data,
      join_date: Moment(data.join_date).format("MM/DD/YYYY, h:mm:ss A"),
    }));

    console.log("dd", dd);

    // moment().format();                                // "2014-09-08T08:02:17-05:00" (ISO 8601, no fractional seconds)
    // moment().format("dddd, MMMM Do YYYY, h:mm:ss a"); // "Sunday, February 14th 2010, 3:25:50 pm"
    // moment().format("ddd, hA");                       // "Sun, 3PM"
    // moment().format("[Today is] dddd");               // "Today is Sunday"
    // moment('gibberish').format('YYYY MM DD');         // "Invalid date"

    // let ss = dd.find((data) => {
    //   if (data.first_name === "Tracey") {
    //     // console.log("sssss", data.first_name);
    //     return data.first_name;
    //   }
    // });

    const ss = dd
      .filter(
        (data) =>
          data.first_name === "Tracey" ||
          data.first_name === "Eve" ||
          data.first_name === "Mark George"
      )
      .map((obj) => obj.first_name);

    console.log(
      "ddddd",
      dd
        .filter(
          (data) =>
            data.first_name === "Tracey" ||
            data.first_name === "Eve" ||
            data.first_name === "Mark George"
        )
        .map((obj) => obj.first_name)
    );

    // // console.log("sssss", this.props);
    // let fileName = "newData.xlsx";
    // // let workbook = excel.readFile(fileName);
    // console.log(fileName) //should print an array with the excel file data

    return (
      <div style={{ padding: "50px 50px" }}>
        {checkCookie() !== null ? "" : <Redirect to="/" />}
        {/* <header className="App-header">Contact Us</header> */}
        Search
        <input type="text" onChange={(e) => this.searchValue(e)} />
        <table>
          <tr>
            <td>Id</td>
            <td>First Name</td>
            <td>Last Name</td>
            <td>Email</td>
            <td>Join Date</td>
          </tr>

          {dd
            .filter(
              (data) =>
                !this.state.value ||
                data.first_name.toLowerCase() === this.state.value ||
                data.id === parseInt(this.state.value) ||
                data.first_name.toLowerCase().includes(this.state.value) ||
                data.join_date.toString() === this.state.value ||
                data.join_date.toString().includes(this.state.value)
            )
            .map((data, i) => {
              return (
                <tr key={i}>
                  <td>{data.id}</td>
                  <td>{data.first_name}</td>
                  <td>{data.last_name}</td>
                  <td>{data.email}</td>
                  <td>{data.join_date}</td>
                </tr>
              );
            })}
        </table>
        <br />
        <div>
          <Select
            mode="multiple"
            style={{ width: "20%" }}
            placeholder="select one country"
            defaultValue={ss}
            // onChange={handleChange}
            optionLabelProp="label"
          >
            {dd.map((data, index) => {
              return <Option value={data.first_name}>{data.first_name}</Option>;
            })}
          </Select>
        </div>
        <br />
        <div>
        <input type="file" onChange={this.onFileChange} /> 
          <Upload
            fileList={this.state.selectedFileList}
            customRequest={dummyRequest}
            onChange={this.onChange}
          >
            <Button icon={<UploadOutlined />}>Upload</Button>
          </Upload>
        </div>
      </div>
    );
  }
}

export default ContactUs;
