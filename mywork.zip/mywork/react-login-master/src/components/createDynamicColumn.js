/* generate dynamic column */
export const createDynamicColumn = (data) => {
  var keys = Object.keys(data[0]);
  const column = keys.map((data1, index) => {
    // console.log(">>>", data1);
    const temp = {
      title:  data1, //`Column${index+1}  ${data1}` ,
      dataIndex: data1,
      key: data1,
    };
    return temp;
  });
  return column;
};
