import React from "react";
import { Button, Layout, Menu } from "antd";
import { connect } from "react-redux";
import { Link,Redirect } from "react-router-dom";
import { setCookie,checkCookie } from "../utils/cookies";
import { LoginOutlined } from "@ant-design/icons";
const { Header, Content } = Layout;

class Home extends React.Component {
  logout = () => {
    if (window.confirm("Are you want to logout?")) {
      setCookie("auth_token", "", 1);
      window.location.href = "/";
    }
  };
  render() {
    const { location } = this.props;
     console.log("epc")
    return (
      <Layout className="layout">
         {checkCookie() !== null ? "" : <Redirect to="/" />}
        {/* <Header>
          <div className="logo" />
          <Menu
            theme="dark"
            mode="horizontal"
            defaultSelectedKeys={["Information"]}
            selectedKeys={[location.pathname]}
          >
            <Menu.Item key="/dashboard">
              <Link
                to={{
                  pathname: "/dashboard",
                }}
              >
                Home
              </Link>
            </Menu.Item>
            <Menu.Item key="/epc">
              <Link
                to={{
                  pathname: "/epc",
                }}
              >
                EPC
              </Link>
            </Menu.Item>
            <Menu.Item key="/contact-us">
              <Link
                to={{
                  pathname: "/contact-us",
                }}
              >
                Contact Us
              </Link>
            </Menu.Item>
            <Button
              onClick={this.logout}
              style={{ float: "right", marginTop: "20px" }}
            >
              <LoginOutlined />
            </Button>
          </Menu>
        </Header> */}
        <Content style={{ padding: "0px 0px" }}>
          <iframe
            frameborder="0"
            marginheight="0"
            marginwidth="0"
            width="100%"
            height="800px"
            // scrolling="auto"
            // src={"http://epcdemo.azurewebsites.net/?token="+checkCookie()}
            src={"http://epcdemo.azurewebsites.net/?token=$"+checkCookie()+"$U2FsdGVkX1/ImtWPPCRH4TBtN3uH/5mw9d7pJFtiXq8=$U2FsdGVkX18J05P6tQPhAewo8hazu0E8U5hjArpuCXE1EU1wwlSeTANNu/60mjHE$U2FsdGVkX18suOsgmCwOAwZ0j8semTjmdAfGZ4t63tJh4W4ASXLdexLAkakoCJtt$U2FsdGVkX1+zEyIP4VvnlPTFN2yAhHBK2PdfWOs4m0A="}
          ></iframe>
        </Content>
      </Layout>
    );
  }
}
const mapStateToProps = (state) => {
  return { data: state.data };
};

// const mapDispatchToProps = (dispatch) =>
//   bindActionCreators({ requestApiData }, dispatch);
export default connect(mapStateToProps, null)(Home);
