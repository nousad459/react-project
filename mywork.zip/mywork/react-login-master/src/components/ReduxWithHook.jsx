import React, { useEffect } from "react";
import { useSelector, useDispatch, useStore } from "react-redux";
import { getCountryAction, getStatesAction, getCityAction } from "../actions/addressAction";
import {
  Table,
  Avatar,
  Pagination,
  Button,
  Popconfirm,
  message,
  Select,
} from "antd";
import { EditFilled, DeleteFilled } from "@ant-design/icons";
const { Option } = Select;

const TodoListItem = (props) => {
  const dispatch = useDispatch();
  useEffect(() => {
    // Update the document title using the browser API
    dispatch(getCountryAction());
  }, []);
  const country = useSelector((state) => state.address.country);
  const states = useSelector((state) => state.address.states);
  const city = useSelector((state) => state.address.city);
  const increment = useSelector((state) => state.increment);

  const store = useStore();

  const { response, loading } = country;
  // const { response, loading } = states;

  function onChange(value) {
    console.log(`selected ${value}`);
    dispatch(getStatesAction(value));
  }
  function onStatesChange(value) {
    console.log(`selected ${value}`);
     dispatch(getCityAction(value));
  }


  console.log("store>>>>>>>>>>", country);
  return (
    <div className="App">
      <div style={{ padding: "50px 50px" }}>
        {/* {console.log(".>>", todo)} */}
        {/* <h1>{todo.response ? todo.response.message : ""}</h1> */}
        <h1>{increment === 0 ? "" : increment}</h1>
        {/* <span>{value}</span> */}
        <br />
        <button onClick={() => dispatch({ type: "INCREMENT" })}>
          Increment counter
        </button>
        {/* <button onClick={() => dispatch(getPlanAction({ user_id: 17 }))}>
          Get Plan
        </button> */}
        <br />
        <Select
          showSearch
          style={{ width: 200 }}
          placeholder="Select a Country"
          optionFilterProp="children"
          onChange={onChange}
          // onFocus={onFocus}
          // onBlur={onBlur}
          // onSearch={onSearch}
          filterOption={(input, option) =>
            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
          }
        >
          {loading === false && response.message === "Countries fetched"
            ? response.result.map((data, i) => {
                return <Option value={data.id}>{data.name}</Option>;
              })
            : ""}
        </Select>
        <br />
        <Select
          showSearch
          style={{ width: 200 }}
          placeholder="Select a State"
          optionFilterProp="children"
          onChange={onStatesChange}
          // onFocus={onFocus}
          // onBlur={onBlur}
          // onSearch={onSearch}
          filterOption={(input, option) =>
            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
          }
        >
          {states.loading === false && states.response.message === "States fetched"
            ? states.response.result.map((data, i) => {
                return <Option value={data.id}>{data.name}</Option>;
              })
            : ""}
        </Select>
        <br />
        <Select
          showSearch
          style={{ width: 200 }}
          placeholder="Select a City"
          optionFilterProp="children"
          // onChange={onStatesChange}
          // onFocus={onFocus}
          // onBlur={onBlur}
          // onSearch={onSearch}
          filterOption={(input, option) =>
            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
          }
        >
          {city.loading === false && city.response.message === "Cities fetched"
            ? city.response.result.map((data, i) => {
                return <Option value={data.id}>{data.name}</Option>;
              })
            : ""}
        </Select>
      </div>
    </div>
  );
};

export default TodoListItem;
