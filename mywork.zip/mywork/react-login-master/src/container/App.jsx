import React, { Component } from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import { getCookie } from "../utils/cookies";
import { connect } from "react-redux";
import PrivateRoute from "./privateRoute";
import LoginPage from "../components/loginPage";
import RegisterPage from "../components/registerPage";
import DashboardPage from "../components/dashboardPage";
import InputNumber from "../components/inputNumber";
import AboutUs from "../components/AboutUs";
import ContactUs from "../components/ContactUs";
import Authors from "../components/Authors";
import TakePlan from "../components/TakePlan";
import HeaderComponent from "../components/header";
import SearchAddress from "../components/serach";
import MultiPartDemo from "../components/MultiPart";
import StepExample from "../components/StepExample";
import DropdownMultiPart from "../components/DropDownMultiPart";
import ReduxWithHook from "../components/ReduxWithHook";
import { refreshToken } from "../utils/refreshToken";
import { refreshTokenAction } from "../actions/authenticationActions";
import { setCookie } from "../utils/cookies";
import ExcelReader from "../components/excelReader";
import axios from "axios";

import "antd/dist/antd.css";
import "./App.css";

axios.interceptors.response.use(
  (res) => {

     if(res.data.message === "jwt expired")
     {
       console.log(">>>>",res);
      //  refreshToken();
     }
    return res;
  },
  (error) => {
    // return handleSimpleApiError({
    //   errors: [{ response: error }],
    // });

    return error
  }
);

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isCookie: "",
    };
  }
  componentDidUpdate(prevProps) {
    if (prevProps.login !== this.props.login) {
      if (
        this.props.login.loading === false &&
        this.props.login.response.response.success === true
      ) {
        this.setState({ isCookie: getCookie("auth_token") });
      }
    }

   
    // console.log("??????", ss);

    if(prevProps.refreshToken!==this.props.refreshToken)
   {
    if (
      this.props.refreshToken.loading === false &&
      this.props.refreshToken.response.success === true
    ) {
      // debugger
      setCookie(
        "auth_token",
        this.props.refreshToken.response.result.access_token,
        1
      );
      
    }
   }
  }

  render() {
    const isCookie = getCookie("auth_token");

    console.log("??????", this.props.refreshToken);
    return (
      <div>
        <BrowserRouter>
          <div>
            {!(this.state.isCookie || isCookie) ? (
              <Switch>
                <Route path="/" exact={true} component={LoginPage} />
                <Route path="/login" component={LoginPage} />
                <Route path="/register" component={RegisterPage} />
                <PrivateRoute path="/*" />
              </Switch>
            ) : (
              <div>
                <HeaderComponent />
                <Switch>
                  <Route exact path="/" component={DashboardPage} />
                  <Route path="/epc" component={AboutUs} />
                  <Route path="/contact-us" component={ContactUs} />
                  <Route path="/show-image" component={InputNumber} />
                  <Route path="/authors" component={Authors} />
                  <Route path="/take-plan" component={TakePlan} />
                  <Route path="/search" component={SearchAddress} />
                  <Route path="/multi-part" component={MultiPartDemo} />
                  <Route path="/step" component={StepExample} />
                  <Route path="/excel" component={ExcelReader} />
                  <Route
                    path="/dropdown-multipart"
                    component={DropdownMultiPart}
                  />
                  <Route path="/redux-hook" component={ReduxWithHook} />
                  <PrivateRoute
                    path="/*"
                    component={() => (
                      <div className="App" style={{ padding: "254px" }}>
                        <h2>404!!! Page not found.</h2>
                      </div>
                    )}
                  />
                </Switch>
              </div>
            )}
          </div>
        </BrowserRouter>
      </div>
    );
  }
}

const mapStateToProps = (response) => ({ login: response.login, refreshToken: response.refreshToken });
const mapDispatchToProps = {
  refreshTokenAction: refreshTokenAction,
};

export default connect(mapStateToProps, mapDispatchToProps)(App);
