var mysql = require("mysql");
var md5 = require("MD5");
var jwt = require("jsonwebtoken"); // used to create, sign, and verify tokens
var config = require("../config");
var connection = require("../database"); // get our config file
const { requestHandler, constant } = require("../utils");

/**
* Function to query from tbCatalog to get all the catalogs.
*
* @return {Promise} The result of database query.

*/

const logout = (req, res, post) => {
  console.log(">>>", req.body.userId);

  var query = "DELETE FROM ?? WHERE ??=?";
  // DELETE FROM `access_token` WHERE user_id

  var table = ["access_token", "user_id", req.body.userId];

  query = mysql.format(query, table);

  connection.query(query, function (err, rows) {
    //  res.json({"sss":rows[0].user_id});
    if (err) {
      res.json({ Error: true, Message: "Error executing MySQL query" });
    } else {
      res.json({ success: false, message: "Token Deleted" });
    }
  });
};

module.exports = {
  logout,
};
