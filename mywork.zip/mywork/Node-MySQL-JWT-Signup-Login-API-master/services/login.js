var mysql = require("mysql");
var md5 = require("MD5");
var jwt = require("jsonwebtoken"); // used to create, sign, and verify tokens
var config = require("../config");
var connection = require("../database"); // get our config file
const { requestHandler, constant } = require("../utils");
const nodemailer = require("nodemailer"); // site link:== https://stackabuse.com/how-to-send-emails-with-node-js/

/**
* Function to query from tbCatalog to get all the catalogs.
*
* @return {Promise} The result of database query.

*/

/**
 *  Function to send mail with MAIL trap
 */

// let transport = nodemailer.createTransport({
//   host: 'smtp.mailtrap.io',
//   port: 2525,
//   auth: {
//      user: '061af5b1333217',
//      pass: '2bbd18bd27006d'
//   }
// });

let mailTransporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "nou.ali111@gmail.com",
    pass: "9621335471",
  },
});

let mailDetails = {
  from: "nou.ali111@gmail.com",
  to: "nousad.ali529@gmail.com",
  subject: "Test mail",
  text: "Node.js testing mail for GeeksforGeeks",
};

const login = (req, res, post) => {
  var query = "SELECT * FROM ?? WHERE ??=? AND ??=?";

  var table = ["user", "password", md5(post.password), "email", post.email];

  query = mysql.format(query, table);

  connection.query(query, function (err, rows) {
    //  res.json({"sss":rows[0].user_id});
    if (err) {
      res.json({ Error: true, Message: "Error executing MySQL query" });
    } else {
      if (rows.length == 1) {
        ///start
        if (rows[0].is_verfied === 1) {
          var token = jwt.sign(rows, config.secret, {
            expiresIn: 3600, // for 1 hour
          });
          user_id = rows[0].user_id;
          var data = {
            user_id: rows[0].user_id,
            device_type: rows[0].device_type,
            access_token: token,
            device_token: rows[0].device_token,
            ip_address: rows[0].ip_address,
          };
          var query = "INSERT INTO  ?? SET  ?";
          var table = ["access_token"];
          query = mysql.format(query, table);
          connection.query(query, data, function (err, rows) {
            if (err) {
              res.json({
                Error: true,
                Message: "Error executing MySQL query",
              });
              // requestHandler.sendError(res, err, err.message)
            } else {
              requestHandler.sendSuccess(
                res,
                data,
                constant.MESSAGES.LOGIN_SUCCESS
              );

              //   const message = {
              //     from: 'nou.ali111@gmail.com', // Sender address
              //     to: 'nousad.ali529@gmail.com',         // List of recipients
              //     subject: 'From Nousad', // Subject line
              //     // text: 'Hello!' // Plain text body
              //     html: '<h1>Have the most fun you can in a car!</h1><p>Get your <b>Tesla</b> today!</p>',
              //     attachments: [
              //       { // Use a URL as an attachment
              //         filename: 'your-testla.png',
              //         path: 'https://media.gettyimages.com/photos/view-of-tesla-model-s-in-barcelona-spain-on-september-10-2018-picture-id1032050330?s=2048x2048'
              //     }
              //   ]
              // };
              // transport.sendMail(message, function(err, info) {
              //     if (err) {
              //       console.log(err)
              //     } else {
              //       console.log(info);
              //     }
              // });

              mailTransporter.sendMail(mailDetails, function (err, data) {
                if (err) {
                  console.log("Error Occurs");
                } else {
                  console.log("Email sent successfully");
                }
              });
            } // return info including token
          });
        } else {
          res.json({
            success: false,
            message: "User not verify",
          });
        }

        ///end
      } else {
        //  requestHandler.sendError(res, error, error.message)
        res.json({
          success: false,
          message: "wrong email/password combination",
        });
      }
    }
  });
};

const refreshTokenService = (req, res, post) => {
  var query = "SELECT * FROM ?? WHERE ??=? AND ??=?";

  var table = [
    "access_token",
    "user_id",
    post.user_id,
    "access_token",
    post.token,
  ];

  query = mysql.format(query, table);

  connection.query(query, function (err, rows) {
    //  res.json({"sss":rows[0].user_id});
    if (err) {
      res.json({ Error: true, Message: "Error executing MySQL query" });
    } else {
      if (rows.length == 1) {
        var refreshToken = jwt.sign(rows, config.secret, {
          expiresIn: 40,
        });
        user_id = rows[0].user_id;
        var data = {
          user_id: rows[0].user_id,
          device_type: rows[0].device_type,
          access_token: refreshToken,
          device_token: rows[0].device_token,
          ip_address: rows[0].ip_address,
        };
        var query = "INSERT INTO  ?? SET  ?";
        var table = ["access_token"];
        query = mysql.format(query, table);
        connection.query(query, data, function (err, rows) {
          if (err) {
            res.json({
              Error: true,
              Message: "Error executing MySQL query",
            });
            // requestHandler.sendError(res, err, err.message)
          } else {
            requestHandler.sendSuccess(
              res,
              data,
              constant.MESSAGES.REFRESH_TOKEN_SUCCESS
            );
          } // return info including token
        });
      } else {
        //  requestHandler.sendError(res, error, error.message)
        res.json({
          success: false,
          message: "wrong email/password combination",
        });
      }
    }
  });
};

module.exports = {
  login,
  refreshTokenService,
};
