const loginService = require('./login');
const logoutService = require('./logout');

module.exports = {
    loginService,
    logoutService
};