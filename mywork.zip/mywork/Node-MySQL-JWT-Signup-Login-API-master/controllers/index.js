const LoginCtrl = require('./userLoginCheck');
const getAuthorPaginationCtrl = require('./getAuthorPagination');
const takePlanCtrl = require('./takePlan');
const logoutCtrl = require('./userLogout');
const addressCtrl = require('./addressController');
const userRegisterCtrl = require('./userRegister');
const studentCtrl = require('./studentController');



module.exports = {
    LoginCtrl,
    getAuthorPaginationCtrl,
    takePlanCtrl,
    logoutCtrl,
    addressCtrl,
    userRegisterCtrl,
    studentCtrl
};