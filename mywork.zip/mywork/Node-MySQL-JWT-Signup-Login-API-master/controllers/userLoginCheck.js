
var mysql   = require("mysql");
var express = require("express");
var md5 = require("MD5");
var jwt = require('jsonwebtoken'); // used to create, sign, and verify tokens
var config = require('../config');
var connection = require("../database"); // get our config file
const {loginService} = require('../services');


/**
* Function to get all the keys by figure id.
*
* @param {Request} req The request.
* @param {Response} res The response.
* @return {Object} The result.
*/
var userLoginCheck = function (req, res) {
  //var em = req.body.email || req.query.email;
  var post = {
    password: req.body.password,
    email: req.body.email,
  };

  loginService.login(req, res, post);
};

var refreshToken = function (req, res) {
	var token =   req.body.token || req.query.token || req.headers['token']|| req.headers.authorization;
	var str = token;
    var splitToken = str.split(" ");
	// const decoded = jwt.decode(splitToken[1], {complete: true});
	var post = {
		user_id: req.body.user_id,
		token: splitToken[1],
	  };
  
	loginService.refreshTokenService(req, res, post);
  };
  

module.exports = { userLoginCheck, refreshToken };



