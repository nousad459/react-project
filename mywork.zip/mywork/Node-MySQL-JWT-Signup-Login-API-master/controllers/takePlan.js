var mysql = require("mysql");
var connection = require("../database"); // get our config file
const { requestHandler, constant } = require("../utils");

/**
 * Function to get all the keys by figure id.
 *
 * @param {Request} req The request.
 * @param {Response} res The response.
 * @return {Object} The result.
 */
var takePlan = async function (req, res) {
  var dataArray = req.body.plan_type;

  var getPlanNameQuey = "SELECT * FROM ?? WHERE ??=? AND ??=?";

  var getPlanNameTable = ["take_plan", "plan_name", req.body.plan_name, "user_id", req.body.user_id];

  getPlanNameQuey = mysql.format(getPlanNameQuey, getPlanNameTable);

  connection.query(getPlanNameQuey, function (err, rowsForCheckPlanName) {
    var query = "INSERT INTO  ?? SET  ?";
    var table = ["take_plan"];
    query = mysql.format(query, table);
    var post = {
      user_id: req.body.user_id,
      plan_name: req.body.plan_name,
    };
    var queryPlanType = "INSERT INTO plan_type (plan_type,plan_name,user_id) VALUES ?";

    var queryList = [];
    dataArray.map((data, index) => {
      var post = [data, req.body.plan_name,req.body.user_id];
      queryList.push(post);
    });

    if (err) {
      requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
    } else {
      if (rowsForCheckPlanName.length > 0) {
        connection.query(queryPlanType, [queryList], function (err, rows) {
          if (err) {
            requestHandler.sendError(
              res,
              err,
              constant.MESSAGES.MYSQL_QUERY_ERROR
            );
          }
        });
        requestHandler.sendSuccess(
          res,
          { rowAffected: rowsForCheckPlanName.affectedRows },
          constant.MESSAGES.SAVE_TAKE_PLAN
        );
      } else {
        connection.query(query, post, function (err, rows) {
          if (err) {
            requestHandler.sendError(
              res,
              err,
              constant.MESSAGES.MYSQL_QUERY_ERROR
            );
          } else {
            connection.query(queryPlanType, [queryList], function (err, rows) {
              if (err) {
                requestHandler.sendError(
                  res,
                  err,
                  constant.MESSAGES.MYSQL_QUERY_ERROR
                );
              }
            });
            requestHandler.sendSuccess(
              res,
              { rowAffected: rows.affectedRows },
              constant.MESSAGES.SAVE_TAKE_PLAN
            );
          }
        });
      }
    }
  });
};

var getPlan = async function (req, res) {
  var query = `SELECT take_plan.PlanPK,take_plan.user_id,take_plan.plan_name,plan_type.plan_type,plan_type.id
  FROM take_plan
  INNER JOIN plan_type ON take_plan.plan_name = plan_type.plan_name WHERE take_plan.user_id=${req.query.user_id} AND plan_type.user_id=${req.query.user_id}`;
  connection.query(query, function (err, takePlanTableData) {
    if (err) {
      requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
    } else {
      let responseArr = [];
      const keyIds = [
        ...new Set(takePlanTableData.map((key) => key.plan_name)),
      ];
      var keyArr;
      responseArr = keyIds;

      const ssss = keyIds.map((plan_name, index) => {
        keyArr = takePlanTableData
          .filter((key) => {
            return key.plan_name === plan_name;
          })
          .map((el) => {
            return {
              planType: el.plan_type,
              planId: el.id,
              takePlanId: el.PlanPK,
            };
          });
        let ss = takePlanTableData
          .filter((key) => {
            return key.plan_name === plan_name;
          })
          .map((el) => el.PlanPK);
        // console.log(">>>>>", ss);

        return {
          userId: takePlanTableData[0].user_id,
          takePlanId: ss[0],
          planName: plan_name,
          planTypes: keyArr,
        };
      });

      requestHandler.sendSuccess(res, ssss, constant.MESSAGES.FETCH_GET_PLAN);
      return;
    }
  });
};

var updatePlanType = async function (req, res) {
  var query = "SELECT * FROM ?? WHERE ??=?  AND ??=? AND ??=?";
  var table = ["plan_type","plan_name",req.body.plan_name,"plan_type",req.body.plan_type, "user_id", req.body.user_id];
  query = mysql.format(query, table);

  connection.query(query, function (err, rows) {
    // console.log(">>>>>",rows.length);return
    if (err) {
      requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
    } else {
      if (rows.length > 0) {
        var deleteQuery = "DELETE FROM ?? WHERE ??=?";
        var table = ["plan_type", "id", req.body.tempData[0].planId];
        deleteQuery = mysql.format(deleteQuery, table);
        connection.query(deleteQuery, function (err, rows) {
          if (err) {
            requestHandler.sendError(
              res,
              err,
              constant.MESSAGES.MYSQL_QUERY_ERROR
            );
          } else {
            requestHandler.sendSuccess(
              res,
              rows,
              constant.MESSAGES.PLAN_EDITED
            );
          }
        });
      } else {
        var queryPlanType =
          "INSERT INTO plan_type (plan_type,plan_name,user_id) VALUES ?";
        let dd = [req.body.plan_type, req.body.plan_name,req.body.user_id];
        var queryList = [];
        queryList.push(dd);

        connection.query(queryPlanType, [queryList], function (err, rows) {
          if (err) {
            requestHandler.sendError(
              res,
              err,
              constant.MESSAGES.MYSQL_QUERY_ERROR
            );
          } else {
            requestHandler.sendSuccess(
              res,
              rows,
              constant.MESSAGES.PLAN_EDITED
            );
          }
        });
      }
    }
  });
};

var deletePlan = async function (req, res) {
  // console.log(">>>>>",req.body);
  // return
  var deleteTakePlanQuery = "DELETE FROM ?? WHERE ??=?";
  var table = ["take_plan", "PlanPK", req.body.planId];
  deleteTakePlanQuery = mysql.format(deleteTakePlanQuery, table);

  connection.query(deleteTakePlanQuery, function (err, rows) {
    if (err) {
      requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
    } else {
      var deletePlanTypeQuery = "DELETE FROM ?? WHERE ??=?";
      var table = ["plan_type", "plan_name", req.body.planName];
      deletePlanTypeQuery = mysql.format(deletePlanTypeQuery, table);
      connection.query(deletePlanTypeQuery, function (err, rows) {
        if (err) {
          requestHandler.sendError(
            res,
            err,
            constant.MESSAGES.MYSQL_QUERY_ERROR
          );
        } else {
          requestHandler.sendSuccess(
            res,
            rows,
            constant.MESSAGES.PLAN_TYPE_DELETED
          );
        }
      });
    }
  });
};

module.exports = { takePlan, getPlan, updatePlanType, deletePlan };
