var mysql = require("mysql");
var connection = require("../database"); // get our config file
const { requestHandler, constant } = require("../utils");

/**
 * Function to get all the keys by figure id.
 *
 * @param {Request} req The request.
 * @param {Response} res The response.
 * @return {Object} The result.
 */
var createStudentDetails = async function (req, res) {
  var post = {
    firstName: req.body.firstName,
    middleName: req.body.middleName,
    lastName: req.body.lastName,
    age: req.body.age,
    dob: req.body.dob,
    grade: req.body.grade,
    motherName: req.body.motherName,
    fatherName: req.body.fatherName,
    sisterName: req.body.sisterName,
    brotherName: req.body.brotherName,
    mobileNumber: req.body.mobileNumber,
    phoneNumber: req.body.phoneNumber,
    address: req.body.address,
    gender: req.body.gender,
  };
  var query = "INSERT INTO  ?? SET  ?";
  var table = ["student_details"];
  query = mysql.format(query, table);

  connection.query(query, post, function (err, rows) {
    if (err) {
      requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
    } else {
      requestHandler.sendSuccess(res, rows, constant.MESSAGES.STUDENT_CREATED);
    }
  });
};

var getStudentDetails = async function (req, res) {
  // var countryId = req.params.id;
  var query = "SELECT * FROM ??";

  var table = ["student_details"];

  query = mysql.format(query, table);

  connection.query(query, function (err, rows) {
    if (err) {
      requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
    } else {
      requestHandler.sendSuccess(res, rows, constant.MESSAGES.STUDENT_FETCHED);
    }
  });
};

var addStudentClassSectionAndSubjects = async function (req, res) {
  var studentId = req.body.studentId;
  var className = req.body.class;
  var section = req.body.section;
  var subjects = req.body.subjects;


  var query = "UPDATE ?? SET  ??=?, ??=?  WHERE ??=?";
  var table = ["student_details", "class", className, "section", section, "id", studentId];

  query = mysql.format(query, table);

  connection.query(query, function (err, rows) {
    if (err) {
      requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
    } else {
    var queryPlanType = "INSERT INTO subject (student_id,subject) VALUES ?";
    var dataList = [];
    subjects.map((data, index) => {
      var post = [req.body.studentId, data.subject];
      dataList.push(post);
    });
      connection.query(queryPlanType, [dataList], function (err, rows1) {
        if (err) {
          requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
        } else {
          requestHandler.sendSuccess(res, rows, constant.MESSAGES.CLASS_SECTION_STUDENT);
        }
      });

    }
  });
};

var getStudentClassSectionAndSubjects = async function (req, res) {
  var studentId = req.query.studentId;

  var query = `SELECT student_details.class, student_details.id, student_details.section, subject.subject,subject.student_id FROM student_details INNER JOIN subject ON student_details.id= subject.student_id WHERE student_details.id=${studentId}`;
  
  connection.query(query, function (err, rows) {
    if (err) {
      requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
    } else {
      var keyArr;
      const keyIds = [
        ...new Set(rows.map((key) => key.id)),
      ];
      const classSectionSubjectDetails = keyIds.map((id, index) => {
        keyArr = rows
          .filter((key) => {
            return key.student_id === id;
          })
          .map((el) => {
            return {
              subject: el.subject,
            };
          });
        

        return {
          class: rows[0].class,
          section: rows[0].section,
          subjects: keyArr,
        };
      });
      requestHandler.sendSuccess(res, classSectionSubjectDetails, constant.MESSAGES.CLASS_SECTION_STUDENT_FETCHED);
    }
  });
};

module.exports = {
  createStudentDetails,
  getStudentDetails,
  addStudentClassSectionAndSubjects,
  getStudentClassSectionAndSubjects
};
