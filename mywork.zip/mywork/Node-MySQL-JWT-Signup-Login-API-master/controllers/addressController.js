var mysql = require("mysql");
var connection = require("../database"); // get our config file
const { requestHandler, constant } = require("../utils");

/**
 * Function to get all the keys by figure id.
 *
 * @param {Request} req The request.
 * @param {Response} res The response.
 * @return {Object} The result.
 */
var getCountries = async function (req, res) {
 
  var query = "SELECT * FROM ??";

  var table = ["tbl_countries"];

  query = mysql.format(query, table);

  connection.query(query, function (err, rows) {
    if (err) {
      requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
    } else {
      requestHandler.sendSuccess(
        res,
        rows,
        constant.MESSAGES.COUNTRY_MSG
      );
    }
  });
};

var getStates = async function (req, res) {

    var countryId = req.params.id;
    var query = "SELECT * FROM ?? WHERE ??=?";
    // SELECT * FROM `tbl_states` WHERE country_id = 1

    var table = ["states","country_id", countryId];
  
    query = mysql.format(query, table);
  
    connection.query(query, function (err, rows) {
      if (err) {
        requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
      } else {
        requestHandler.sendSuccess(
          res,
          rows,
          constant.MESSAGES.STATE_MSG
        );
      }
    });
  
};

var getCities = async function (req, res) {
    var stateId = req.params.id;
    var query = "SELECT * FROM ?? WHERE ??=?";
    var table = ["cities", "state_id", stateId];

    query = mysql.format(query, table);
  
    connection.query(query, function (err, rows) {
      if (err) {
        requestHandler.sendError(res, err, constant.MESSAGES.MYSQL_QUERY_ERROR);
      } else {
        requestHandler.sendSuccess(
          res,
          rows,
          constant.MESSAGES.CITY_MSG
        );
      }
    });
};



module.exports = { getCountries, getStates, getCities };
