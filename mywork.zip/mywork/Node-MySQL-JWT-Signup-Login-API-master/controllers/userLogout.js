
const {logoutService} = require('../services');


/**
* Function to get all the keys by figure id.
*
* @param {Request} req The request.
* @param {Response} res The response.
* @return {Object} The result.
*/
var userLogout = function (req, res) {

	//var em = req.body.email || req.query.email;
	var post  = {
		password:req.body.password,
		email:req.body.email
	}

	logoutService.logout(req,res,post);

	
}

module.exports = { userLogout };


