var mysql = require("mysql");
var connection = require("../database"); // get our config file

/**
 * Function to get all the keys by figure id.
 *
 * @param {Request} req The request.
 * @param {Response} res The response.
 * @return {Object} The result.
 */
var getAuthorPagination = function (req, res) {
  var page = req.query.page;
  var limit = req.query.limit;
  var skip = (page - 1) * limit;

  var query = `SELECT * FROM authors ORDER BY id LIMIT ${skip},${limit}`;
  query = mysql.format(query);

  connection.query(query, function (err, rows) {
    if (err) {
      res.json({ Error: true, Message: "Error executing MySQL query" });
    } else {
      var query1 = `SELECT * FROM authors`;
      query1 = mysql.format(query1);

      connection.query(query1, function (err, totalRows) {
        if (err) {
          res.json({ Error: true, Message: "Error executing MySQL query" });
        } else {
          res.json({
            Error: false,
            Message: "Success",
            result: rows,
            Total: totalRows.length,
          });
        }
      });
    }
  });
};

module.exports = { getAuthorPagination };
