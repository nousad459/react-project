var express = require("express");
const fileUpload = require("express-fileupload");
var http = require("http");
var mysql = require("mysql");
var bodyParser = require("body-parser");
var md5 = require("MD5");
var config = require("./config");
var config = require("./database");

const cors = require("cors");

var verifyToken = require("./middleware/verifyToken");
var addNewUser = require("./middleware/addNewUser");
var userLoginCheck = require("./middleware/userLoginCheck");
var findAllUsers = require("./middleware/findAllUsers");
var findUserById = require("./middleware/findUserById");
var welcome = require("./middleware/welcome");
var profile = require("./middleware/profile");
var getImage = require("./middleware/getImage");
var getAuthors = require("./middleware/getAuthors");
var getAuthorPagination = require("./middleware/getAuthorPagination");
var {
  loginRouter,
  getAuthorPaginationRouter,
  takePlanRouter,
  logoutRouter,
  addressRouter,
  userRegisterRouter,
  studentRouter
} = require("./routes");
const { loginLogout } = require("./services");

var port = process.env.PORT || 4200;

//var twilio = require('twilio');
var app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.listen(port, function () {
  console.log("Express server listening on port " + port);
});

// enable files upload
app.use(
  fileUpload({
    createParentPath: true,
    // limits: {
    //     fileSize: 2 * 1024 * 1024 * 1024 //2MB max file(s) size
    // },
  })
);

// If you want to make the uploaded files publicly accessible from anywhere, just make the uploads directory static
app.use(express.static("uploads"));

app.post("/signup", addNewUser);
// app.post('/userlogin', userLoginCheck);
app.use("/api", loginRouter);
app.use("/api", getAuthorPaginationRouter);
app.use("/api", takePlanRouter);
app.use("/api", logoutRouter);
app.use("/api", addressRouter);
app.use("/api", userRegisterRouter);
app.use("/api", studentRouter);


var apiRoutes = express.Router();
apiRoutes.use(bodyParser.urlencoded({ extended: true }));
apiRoutes.use(bodyParser.json());
//route middleware to verify a token
apiRoutes.use(verifyToken);
apiRoutes.get("/", welcome);
apiRoutes.get("/users", findAllUsers);
apiRoutes.get("/user/:id", findUserById);
apiRoutes.get("/image", getImage);
apiRoutes.post("/profile", profile);
apiRoutes.get("/authors", getAuthors);
// apiRoutes.get('/authorPagination', getAuthorPagination);

app.use("/api", apiRoutes);

//app.use(bodyParser());

// function REST(){
//     var self = this;
//     self.connectMysql();
// };

// REST.prototype.connectMysql = function() {
//     var self = this;
//     var pool      =    mysql.createPool({
//         connectionLimit : 100,
//         host     : 'localhost',
//         user     : 'root',
//         password : '',
//         database : 'lyive',
//         debug    :  true
//     });
//     pool.getConnection(function(err,connection){
//         if(err) {
//           self.stop(err);
//         } else {
//           self.configureExpress(connection);
//         }
//     });
// }

//app.post('/userlogin', userLoginCheck);

// REST.prototype.configureExpress = function(connection) {
//       var self = this;
//       app.use(bodyParser.urlencoded({ extended: true }));
//       app.use(bodyParser.json());
//       var router = express.Router();
//       app.use('/api', router);
//       router.use(verifyToken);
//       var rest_router = new rest(router,connection,md5);
//       self.startServer();
// }

// REST.prototype.startServer = function() {
//       app.listen(4200,function(){
//           console.log("All right ! I am alive at Port 4200.");
//       });
// }

// REST.prototype.stop = function(err) {
//     console.log("ISSUE WITH MYSQL \n" + err);
//     process.exit(1);
// }

// new REST();
