module.exports = {
  // secret: used when we create and verify JSON Web Tokens
  secret: "jsismagic",
};
