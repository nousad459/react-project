
var mysql   = require("mysql");
var connection = require("../database");

var getAllAuthors = function (req, res) {
	var query = "SELECT * FROM ?? ";

    var table = ["authors"];

    query = mysql.format(query,table);

    connection.query(query,function(err,rows){
        if(err) {
            res.json({"Error" : true, "Message" : "Error executing MySQL query"});
        } else {
            res.json({"Error" : false, "Message" : "Success", "Users" : rows});
        }
    });
};
module.exports = getAllAuthors;