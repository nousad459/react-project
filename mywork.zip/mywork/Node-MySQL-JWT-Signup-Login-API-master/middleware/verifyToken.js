
// get our mongoose model
var jwt = require('jsonwebtoken'); // used to create, sign, and verify tokens
var config = require('../config'); // get our config file

/**
 * This api is use to verify token for each request,
 * when client requests with a token this API decodes that match with existing token  and send with 
 * decoded object.
 * We set currUser i.e. current user to req object so we can access somewhere else.
 * 
 */
 
var verifyToken=function (req, res, next) {
		//  console.log(">>token", base64Encode(req.headers.authorization))
		
	var token =   req.body.token || req.query.token || req.headers['token']|| req.headers.authorization;
	 if (token) {
		// verify secret and checks exp
		var str = token;
		var splitToken = str.split(" ");
		
		jwt.verify(splitToken[1], config.secret, function (err, currUser) {
		
			if (err) {
				res.send(err);
			} else {
				// decoded object
				const decoded = jwt.decode(splitToken[1], {complete: true});
		        console.log(">>>>>>>decode",decoded);
				req.query.currUser = currUser;
				next();
			}
		});
	}
	 else {
		// send not found error
		//res.send(401, " ");
		res.status(401).send("Invalid Access");
	}
};
module.exports=verifyToken;