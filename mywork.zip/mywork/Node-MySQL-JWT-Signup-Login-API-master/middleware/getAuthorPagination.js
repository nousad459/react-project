
var mysql   = require("mysql");
var connection = require("../database"); // get our config file


/**
* Function to get all the keys by figure id.
*
* @param {Request} req The request.
* @param {Response} res The response.
* @return {Object} The result.
*/
var getAuthorPagination = function (req, res) {

    var page = req.query.page;
    var limit = req.query.limit;

    // var query = 'SELECT * FROM `authors` ORDER BY id LIMIT'+page+','+limit;
    var query = `SELECT * FROM authors ORDER BY id LIMIT ${page},${limit}`;

    // query = query+0+","+10;
    // var table = ["authors"];
     query = mysql.format(query);

    connection.query(query,function(err,rows){
        if(err) {
            res.json({"Error" : true, "Message" : "Error executing MySQL query"});
        } else {
            res.json({"Error" : false, "Message" : "Success", "Users" : rows});
        }
    });
}

module.exports = getAuthorPagination;



