var mysql = require("mysql");
// var express = require("express");
// var jwt = require("jsonwebtoken"); // used to create, sign, and verify tokens
// var config = require("../config");
var connection = require("../database");

var profile = function (req, res, next) {
  console.log("files",req)
  try {
    if (!req.files) {
      res.send({
        status: false,
        message: "No file uploaded",
      });
    } else {
      //Use the name of the input field (i.e. "avatar") to retrieve the uploaded file
      let avatar = req.files.avatar;

      //Use the mv() method to place the file in upload directory (i.e. "uploads")
      avatar.mv("./uploads/" + avatar.name);

      //send response
      res.send({
        status: true,
        message: "File is uploaded",
        data: {
          name: avatar.name,
          mimetype: avatar.mimetype,
          size: avatar.size,
          imageUrl: "http://localhost:4200/" + avatar.name
        },
      });
    }
  } catch (err) {
    res.status(500).send(err);
  }
};
module.exports = profile;
