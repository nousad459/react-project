var mysql = require("mysql");
// var express = require("express");
// var jwt = require("jsonwebtoken"); // used to create, sign, and verify tokens
// var config = require("../config");
var connection = require("../database");

var findUserById = function (req, res, next) {
  var userId = req.params.id;
  
  var query = "SELECT * FROM ?? WHERE ??=? ";

  var table = ["user", "user_id", userId];

  query = mysql.format(query, table);

  connection.query(query, function (err, rows) {
    if (err) {
        // console.log("Request Id:", err);
      res.json({ Error: true, Message: "Error executing MySQL query" });
    } else {
      if (rows.length === 0) {
        res
          .status(400)
          .json({
            Error: true,
            Message: `No record found of this user id ${userId}`,
            Users: rows,
          });
      } else {
        res.json({ Error: false, Message: "Success", Users: rows });
      }
    }
  });
  // next();
};
module.exports = findUserById;
