var mysql = require("mysql");
// var express = require("express");
// var jwt = require("jsonwebtoken"); // used to create, sign, and verify tokens
// var config = require("../config");
var connection = require("../database");

var getImage = function (req, res, next) {
  //send response
  res.send({
    status: true,
    message: "success",
    imageUrl: "http://localhost:4200/" + avatar.name,
  });
};
module.exports = getImage;
