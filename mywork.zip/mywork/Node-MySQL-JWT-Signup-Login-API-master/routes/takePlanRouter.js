const express = require('express')
const router = express.Router()

const { takePlanCtrl } = require("../controllers");
const { validator } = require("../utils");
const verifyToken = require("../middleware/verifyToken");

router.post('/takePlan',
      validator.bodyValidation,
      verifyToken,
      takePlanCtrl.takePlan
);

router.get('/getPlan',
      // validator.bodyValidation,
      verifyToken,
      takePlanCtrl.getPlan
);

router.post('/updatePlanType',
      // validator.bodyValidation,
      verifyToken,
      takePlanCtrl.updatePlanType
);

router.delete('/deletePlan',
      // validator.bodyValidation,
      verifyToken,
      takePlanCtrl.deletePlan
);
module.exports = router;
