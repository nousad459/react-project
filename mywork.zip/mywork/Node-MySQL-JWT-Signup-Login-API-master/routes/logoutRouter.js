const express = require('express')
const router = express.Router()

const {logoutCtrl} = require('../controllers')
 const {validator} = require('../utils')

router.post('/logout',
    //  validator.bodyValidation,
    //  validator.loginValidation,
    // validator.getKeyValidation,
    logoutCtrl.userLogout
);

module.exports = router;
