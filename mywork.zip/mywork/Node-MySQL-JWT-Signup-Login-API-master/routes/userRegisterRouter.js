const express = require('express')
const router = express.Router()

const {userRegisterCtrl} = require('../controllers')
 const {validator} = require('../utils')

router.post('/register',
     validator.registerValidateFields(),
      validator.validate,
    // validator.getKeyValidation,
    userRegisterCtrl.userRegister
);

router.get('/userVerify',
    //  validator.registerValidateFields(),
    //   validator.registerValidate,
    // validator.getKeyValidation,
    userRegisterCtrl.verifyUser
);


module.exports = router;
