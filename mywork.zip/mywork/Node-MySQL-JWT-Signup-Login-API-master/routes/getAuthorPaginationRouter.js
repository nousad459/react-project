const express = require('express')
const router = express.Router()

const { getAuthorPaginationCtrl } = require("../controllers");
const { validator } = require("../utils");
const verifyToken = require("../middleware/verifyToken");

router.get('/authorPagination',
     validator.queryStringValidation,
      verifyToken,
    getAuthorPaginationCtrl.getAuthorPagination
);

module.exports = router;
