const express = require('express')
const router = express.Router();
const {studentCtrl} = require('../controllers');
 const {validator} = require('../utils');
 const verifyToken = require("../middleware/verifyToken");

router.post('/createStudentDetails',
     
      validator.createStudentDetailsValidateFields(),
      validator.validate, 
      verifyToken,
      studentCtrl.createStudentDetails
);

router.get('/getStudentDetails',
      verifyToken,
      studentCtrl.getStudentDetails ,
     
);


router.post('/addStudentClassSectionAndSubjects',
    verifyToken,
    studentCtrl.addStudentClassSectionAndSubjects
);

router.get('/getStudentClassSectionAndSubjects',
    verifyToken,
    studentCtrl.getStudentClassSectionAndSubjects
);


module.exports = router;
