const express = require('express')
const router = express.Router()

const {LoginCtrl} = require('../controllers')
 const {validator} = require('../utils');

router.post('/userLogin',
     validator.bodyValidation,
     validator.loginValidation,
    // validator.getKeyValidation,
    LoginCtrl.userLoginCheck
);

router.post('/refreshToken',
    //  validator.bodyValidation,
    //  validator.loginValidation,
    // validator.getKeyValidation,
    LoginCtrl.refreshToken
);


module.exports = router;
