const loginRouter = require('./login-router');
 const getAuthorPaginationRouter = require('./getAuthorPaginationRouter');
 const takePlanRouter = require('./takePlanRouter');
 const logoutRouter = require('./logoutRouter');
 const addressRouter = require('./addressRouter');
 const userRegisterRouter = require('./userRegisterRouter');
 const studentRouter = require('./studentRouter');


module.exports = {
    loginRouter,
    getAuthorPaginationRouter,
    takePlanRouter,
    logoutRouter,
    addressRouter,
    userRegisterRouter,
    studentRouter
};