const express = require('express')
const router = express.Router()

const { addressCtrl } = require("../controllers");
const { validator } = require("../utils");
const verifyToken = require("../middleware/verifyToken");

router.get('/getCountries',
    //   validator.bodyValidation,
      verifyToken,
      addressCtrl.getCountries
);

router.get('/getStates/:id',
      // validator.bodyValidation,
      verifyToken,
      addressCtrl.getStates
);

router.get('/getCities/:id',
      // validator.bodyValidation,
      verifyToken,
      addressCtrl.getCities
);

module.exports = router;
