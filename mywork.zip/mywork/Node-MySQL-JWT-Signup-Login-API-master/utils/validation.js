const { MESSAGES } = require("./constant");
const { sendBadRequest } = require("./requestHandler");
const { body, validationResult } = require("express-validator");

// express-validator API: https://npmdoc.github.io/node-npmdoc-express-validator/build/apidoc.html

/**
 * This is useful in validating request body.
 *
 * @param {Request} req The request.
 * @param {Response} res The response.
 * @return {Function} next - The callback if true.
 */
const bodyValidation = (req, res, next) => {
  const body = req.body;
  const bodyParams = Object.keys(body);
  if (bodyParams.length === 0 && body.constructor === Object) {
    sendBadRequest(res, MESSAGES.INVALID_BODY);
  } else {
    next();
  }
};

/** for validate User Register Controller */

const registerValidateFields = () => {
  return [
	// body("first_name").isEmail(),
	body("first_name").not().isEmpty(),
	body("last_name").not().isEmpty(),
	body("email").isEmail(),
    // password must be at least 10 chars long and ,
    body("password").isAlphanumeric()
	.withMessage('Must be Alphanumeric chars')
	.isLength({ min: 5 })
	.withMessage('Must be at least 5 chars long'),
	body("dob").not().isEmpty(),
	// body("last_name").not().isEmpty(),
  ];
};


/** for validate createStudentDetails Controller */

const createStudentDetailsValidateFields = () => {
  return [
    // body("first_name").isEmail(),
    body("firstName").not().isEmpty(),
    body("lastName").not().isEmpty(),
    body("age").notEmpty().isInt(),
    body("dob").isDate().withMessage("Date of birth format should be YYYY-MM-DD"),
    body("grade")
      .isAlpha()
      .withMessage("Must be Alphabetic chars")
      .isUppercase()
      .withMessage("Must be uppercase chars")
      .isLength({ max: 1 })
      .withMessage("Only one char for grade"),
    body("motherName").not().isEmpty(),
    body("fatherName").not().isEmpty(),
    body("mobileNumber").isMobilePhone().
    withMessage("Mobile not valid"),
    body("address").notEmpty().withMessage("Enter address"),
    body("gender").notEmpty().withMessage("Select gender"),
  ];
};

const validate = (req, res, next) => {
  // Finds the validation errors in this request and wraps them in an object with handy functions
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  } else {
    next();
  }
  //  validator.loginValidation,
  // validator.getKeyValidation,
};

const queryStringValidation = (req, res, next) => {
  const query = req.query;
  const queryString = Object.keys(query);
  if (queryString.length === 0 && query.constructor === Object) {
    sendBadRequest(res, MESSAGES.INVALID_QUERY_STRING);
  } else {
    next();
  }
};

/**
 * This is useful in validating request body to get all keys.
 *
 * @param {Request} req The request.
 * @param {Response} res The response.
 * @return {Function} next - The callback if true.
 */
const loginValidation = (req, res, next) => {
  const body = req.body;
  const bodyParams = Object.keys(body);
  if (bodyParams.includes("email") && bodyParams.includes("password")) {
    debugger;
    next();
  } else {
    sendBadRequest(res, MESSAGES.INVALID_PARAMS);
  }
};

module.exports = {
  bodyValidation,
  loginValidation,
  queryStringValidation,
  registerValidateFields,
  validate,
  createStudentDetailsValidateFields
};
