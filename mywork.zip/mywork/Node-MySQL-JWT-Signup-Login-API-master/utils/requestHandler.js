const {MESSAGES} = require('./constant');
const log = require('./logger');

/**
* This is useful to send success response.
*
* @param {response} res The response.
* @param {object} result The result to response.
* @param {string} message The message to response.
* @return {Object} The response.
*/
const sendSuccess = (res, result = {}, message) => {
	const response = {};
	response.success = true;
	if (message) {
		response.message = message;
	}
	response.time = new Date().getTime();
	response.result = result;
	return res.status(200).json(response);
};

/**
* This is useful to send error response.
*
* @param {response} res The response.
* @param {object} err The result to response.
* @param {string} message The message to response.
* @return {Object} The response.
*/
const sendError = (res, err = {}, message) => {
	const response = {};
	let errorCode = 404;
	response.success = false;
	response.time = new Date().getTime();
	if (!err.code) {
		response.error = { code: 500, message: MESSAGES.INTERNAL_SERVER };
		errorCode = 500;
	} else {
		if (message) {
			response.message = message;
		}
		response.error = err;
	}
	log.error({error: response});
	return res.status(errorCode).json(response);
};


/**
* This is useful to send error response.
*
* @param {object} err The result to response.
* @param {string} message The message to response.
* @return {Object} The response.
*/
const sendOtherError = (res, err = {}, message) => {
	const response = {};
	let errorCode = 404;
	response.success = false;
	response.time = new Date().getTime();
	if (!err.code) {
		response.error = { code: 500, message: MESSAGES.INTERNAL_SERVER };
		errorCode = 500;
	} else {
		if (message) {
			response.message = message;
		}
		response.error = err;
	}
	log.error({error: response});
	return res.status(errorCode).json(response);
};


/**
* This is useful to send bad request error.
*
* @param {response} res The response.
* @param {string} message The message to response.
* @return {Object} The response.
*/
const sendBadRequest = (res, message) => {
	const response = {};
	let errorCode = 400;
	response.success = false;
	if (message) {
		response.error = message;
	} else {
		response.error = MESSAGES.SOMETHING_WRONG;
	}
	response.time = new Date().getTime();
	log.error({error: response});
	return res.status(errorCode).json(response);
};

module.exports = {
	sendSuccess,
	sendError,
	sendBadRequest
};