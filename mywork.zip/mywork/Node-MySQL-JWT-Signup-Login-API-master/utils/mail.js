const nodemailer = require('nodemailer');
var mailTransporter = nodemailer.createTransport({ 
    service: 'gmail', 
    auth: { 
        user: 'nou.ali111@gmail.com', 
        pass: '9621335471'
    } 
  }); 
  

module.exports = mailTransporter;