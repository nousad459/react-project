import { BrowserRouter, Route, Switch } from "react-router-dom";
import LoginComponent from "../../src/Component/Login/Login";
import Dashboard from "../Component/Pages/Dashboard/Dashboard";
import PrivateRoute from "../Container/privateRoute";
import { handleSimpleApiError, handleSimpleApiSuccess } from "../Utils/api";
// import { deleteAllCookies } from "../Utils/cookies";
// import { message } from "antd";
import axios from "axios";
import "antd/dist/antd.css";
import "./App.scss";

axios.interceptors.response.use(
  (res) => handleSimpleApiSuccess(res),
  (error) => {
    return handleSimpleApiError({
      errors: [{ response: error }],
    });
  }
);

function App() {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/" restricted={false} component={LoginComponent} exact />
        <PrivateRoute component={Dashboard} path="/dashboard" exact />
        <PrivateRoute path="*" component={Dashboard} />
      </Switch>
    </BrowserRouter>
  );
}

export default App;
