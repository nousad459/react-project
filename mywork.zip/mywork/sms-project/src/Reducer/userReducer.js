import * as types from "../Action";
import { combineReducers } from "redux";

/*Reducer for user logout */
function userLogoutReducer(state = [], action) {
  let response = action.response;
  switch (action.type) {
    case types.LOGOUT_USER:
      return { loading: true, ...state };
    case types.LOGOUT_USER_SUCCESS:
      return { loading: false, response };
    case types.LOGOUT_USER_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

/*Reducer for user login */
function userLoginReducer(state = [], action) {
  const response = action.response;
  switch (action.type) {
    case types.LOGIN_USER:
      return { loading: true, ...state };
    case types.LOGIN_USER_SUCCESS:
      return { loading: false, response };
    case types.LOGIN_USER_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

/*Reducer for user token refresh */
function refreshTokenReducer(state = [], action) {
  const response = action.response;
  switch (action.type) {
    case types.REFRESH_TOKEN:
      return { loading: true, ...state };
    case types.REFRESH_TOKEN_SUCCESS:
      return { loading: false, response };
    case types.REFRESH_TOKEN_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

export default combineReducers({
  logout: userLogoutReducer,
  login: userLoginReducer,
  refreshToken: refreshTokenReducer,
});
