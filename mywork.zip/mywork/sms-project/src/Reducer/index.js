import { combineReducers } from "redux";
import user from "./userReducer";
import student from "./studentReducer";

/*this is root reducer */
export default combineReducers({
  user,
  student,
});
