import * as types from "../Action";
import { combineReducers } from "redux";

/*Reducer for user logout */
function createStudentDetailReducer(state = [], action) {
  let response = action.response;
  switch (action.type) {
    case types.CREATE_STUDENT_DETAILS:
      return { loading: true, ...state };
    case types.CREATE_STUDENT_DETAILS_SUCCESS:
      return { loading: false, response };
    case types.CREATE_STUDENT_DETAILS_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

/*Reducer for user logout */
function getStudentDetailReducer(state = [], action) {
  let response = action.response;
  switch (action.type) {
    case types.GET_STUDENT_DETAILS:
      return { loading: true, ...state };
    case types.GET_STUDENT_DETAILS_SUCCESS:
      return { loading: false, response };
    case types.GET_STUDENT_DETAILS_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

/*Reducer for user logout */
function addClassSectionAndSubjectReducer(state = [], action) {
  let response = action.response;
  switch (action.type) {
    case types.ADD_CLASS_SECTION_SUBJECT_DETAILS:
      return { loading: true, ...state };
    case types.ADD_CLASS_SECTION_SUBJECT_DETAILS_SUCCESS:
      return { loading: false, response };
    case types.ADD_CLASS_SECTION_SUBJECT_DETAILS_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

/*Reducer for user logout */
function getClassSectionAndSubjectReducer(state = [], action) {
  let response = action.response;
  switch (action.type) {
    case types.GET_CLASS_SECTION_SUBJECT_DETAILS:
      return { loading: true, ...state };
    case types.GET_CLASS_SECTION_SUBJECT_DETAILS_SUCCESS:
      return { loading: false, response };
    case types.GET_CLASS_SECTION_SUBJECT_DETAILS_ERROR:
      return { loading: false, response };
    default:
      return state;
  }
}

/*Reducer for user logout */
function clearClassSectionAndSubjectReducer(state = [], action) {
  let response = action.response;
  // debugger
  switch (action.type) {
    case types.CLEAR_CLASS_SECTION_SUBJECT_DETAILS:
      return { loading: false, state:[] };
    default:
      return state;
  }
}



export default combineReducers({
  createStudentDetails: createStudentDetailReducer,
  getStudentDetails: getStudentDetailReducer,
  addClassSection: addClassSectionAndSubjectReducer,
  getClassSection: getClassSectionAndSubjectReducer,
  clear: clearClassSectionAndSubjectReducer
});
