import { fork } from 'redux-saga/effects';
import watchUserAuthentication from './watchers';

/*this function use for start saga */
export default function* startApplication() {
  yield fork(watchUserAuthentication);
}


