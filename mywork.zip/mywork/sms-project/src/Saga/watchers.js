import { takeLatest } from "redux-saga/effects";

import { loginSaga, logoutSaga, tokenRefreshSaga } from "./authenticationSaga";
import * as studentSaga from "./studentDetailsSaga";

import * as type from "../Action";

/*this function use for watch every action */

export default function* watchUserAuthentication() {
  yield takeLatest(type.LOGIN_USER, loginSaga);
  yield takeLatest(type.LOGOUT_USER, logoutSaga);
  yield takeLatest(type.CREATE_STUDENT_DETAILS, studentSaga.createStudentSaga);
  yield takeLatest(type.GET_STUDENT_DETAILS, studentSaga.getStudentSaga);
  yield takeLatest(type.ADD_CLASS_SECTION_SUBJECT_DETAILS, studentSaga.addClassSectionAndSubjectSaga);
  yield takeLatest(type.GET_CLASS_SECTION_SUBJECT_DETAILS, studentSaga.getClassSectionAndSubjectSaga);
}
