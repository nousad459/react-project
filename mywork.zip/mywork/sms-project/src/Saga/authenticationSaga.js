import { put, call, } from 'redux-saga/effects';
import * as api from '../Utils/api';
import {loginService,logoutService} from "../Service/authenticationServices"

import * as types from '../Action'

/*Saga for user logout */
export function* logoutSaga(payload) {
  try {
    const response = yield call(logoutService, payload.userId);
    yield put({ type: types.LOGOUT_USER_SUCCESS, response});
  } catch (error) {
    if(error.response){
    yield put({ type: types.LOGOUT_USER_ERROR, response:error.response.data});
    }else{
      yield put({ type: types.LOGOUT_USER_ERROR, response:{error:"Error"}});
    }
  }
}

/*Saga for user login */
export function* loginSaga(payload) {
  try {
    const response = yield call(loginService, payload.user);
    yield put({ type: types.LOGIN_USER_SUCCESS, response });
  } catch (error) {
    yield put({ type: types.LOGIN_USER_ERROR, error })
  }
}

/*Saga for token refresh */
export function* tokenRefreshSaga() {
  try {
    const response = yield call(api.post,'api/refresh');
    yield put({ type: types.REFRESH_TOKEN_SUCCESS, response });
  } catch (error) {
    yield put({ type: types.REFRESH_TOKEN_ERROR, error })
  }
}

