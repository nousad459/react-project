import { put, call, } from 'redux-saga/effects';
import * as studentsServices from "../Service/studentServices";

import * as types from '../Action'

/*Saga for create student details */
export function* createStudentSaga(payload) {
  try {
    const response = yield call(studentsServices.createStudentDetailsService, payload.payload);
    yield put({ type: types.CREATE_STUDENT_DETAILS_SUCCESS, response});
  } catch (error) {
    if(error.response){
    yield put({ type: types.CREATE_STUDENT_DETAILS_ERROR, response:error.response.data});
    }else{
      yield put({ type: types.CREATE_STUDENT_DETAILS_ERROR, response:{error:"Error"}});
    }
  }
}


/*Saga for create student details */
export function* getStudentSaga() {
  try {
    const response = yield call(studentsServices.getStudentDetailsService);
    yield put({ type: types.GET_STUDENT_DETAILS_SUCCESS, response});
  } catch (error) {
    if(error.response){
    yield put({ type: types.GET_STUDENT_DETAILS_ERROR, response:error.response.data});
    }else{
      yield put({ type: types.GET_STUDENT_DETAILS_ERROR, response:{error:"Error"}});
    }
  }
}



/*Saga for create student details */
export function* addClassSectionAndSubjectSaga(payload) {
  try {
    const response = yield call(studentsServices.addClassSectionAndStudentService, payload.payload);
    yield put({ type: types.ADD_CLASS_SECTION_SUBJECT_DETAILS_SUCCESS, response});
  } catch (error) {
    if(error.response){
    yield put({ type: types.ADD_CLASS_SECTION_SUBJECT_DETAILS_ERROR, response:error.response.data});
    }else{
      yield put({ type: types.ADD_CLASS_SECTION_SUBJECT_DETAILS_ERROR, response:{error:"Error"}});
    }
  }
}


/*Saga for create student details */
export function* getClassSectionAndSubjectSaga(studentId) {
  try {
    const response = yield call(studentsServices.getClassSectionAndStudentService, studentId.studentId);
    yield put({ type: types.GET_CLASS_SECTION_SUBJECT_DETAILS_SUCCESS, response});
  } catch (error) {
    if(error.response){
    yield put({ type: types.GET_CLASS_SECTION_SUBJECT_DETAILS_ERROR, response:error.response.data});
    }else{
      yield put({ type: types.GET_CLASS_SECTION_SUBJECT_DETAILS_ERROR, response:{error:"Error"}});
    }
  }
}

