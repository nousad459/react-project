import React, { useEffect, useState } from "react";
import { Layout, Menu, Dropdown, message, Popconfirm } from "antd";
import { useDispatch } from "react-redux";
import { userLogoutAction } from "../../Action/authenticationActions";
import {
  ProfileOutlined,
  SettingOutlined,
  LogoutOutlined,
  UserOutlined,
} from "@ant-design/icons";

const { Header } = Layout;

const HeaderComponent = (props) => {
  const dispatch = useDispatch();
  // const [loading, setLoading] = useState(false);
  // const logout = useSelector((state) => state.user.logout);
  // useEffect(() => {
  //   if (logout.loading === false && logout.response?.message === "Token Deleted") {
  //     setCookie("token", "");
  //     debugger
  //     // BrowserRouter
  //     // props.history.push("/");
  //     // setLoading(false);
  //   }
  //   // if (user.response?.message === "wrong email/password combination") {
  //   //   setLoading(false);
  //   // }
  // });
  function confirm() {
    dispatch(userLogoutAction({ userId: 25 }));
  }
  const menu = (
    <Menu onClick={handleMenuClick}>
      <Menu.Item key="1" icon={<ProfileOutlined />}>
        Profile
      </Menu.Item>
      <Menu.Item key="2" icon={<SettingOutlined />}>
        Setting
      </Menu.Item>
      <Menu.Item key="3" icon={<LogoutOutlined />}>
        <Popconfirm
          placement="topRight"
          title={"Are you want to logout?"}
          onConfirm={confirm}
          okText="Yes"
          cancelText="No"
        >
          Logout
        </Popconfirm>
      </Menu.Item>
    </Menu>
  );

  function handleButtonClick(e) {
    message.info("Click on left button.");
    console.log("click left button", e);
  }

  function handleMenuClick(e) {
    console.log("click", e.key);
    if (e.key === "3") {
      // dispatch(userLogoutAction({ userId: 25 }));
      // message.info("Click on menu item.");
    }
  }

  return (
    <Header className="site-layout-background" style={{ padding: 0 }}>
      <div style={{ padding: "10px 30px" }}>
        {/* <Avatar
            style={{
              float: "right",
              color: "#f56a00",
              backgroundColor: "#fde3cf",
            }}
          > */}
        <Dropdown.Button
          style={{
            float: "right",
            color: "#f56a00",
            backgroundColor: "#fde3cf",
          }}
          overlay={menu}
          icon={<UserOutlined />}
          onClick={handleButtonClick}
        >
          U
        </Dropdown.Button>
        {/* </Avatar> */}
      </div>
    </Header>
  );
};

export default HeaderComponent;
