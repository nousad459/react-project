import React, { Component } from "react";
import { withRouter, Link } from "react-router-dom";
import { Layout, Menu } from "antd";
import {
  HomeOutlined,
  FileOutlined,
  TeamOutlined,
  UserOutlined,
} from "@ant-design/icons";

const { Sider } = Layout;
const { SubMenu } = Menu;

class SideBar extends Component {
  state = {
    collapsed: false,
  };

  onCollapse = (collapsed) => {
    console.log(collapsed);
    this.setState({ collapsed });
  };

  render() {
    const { collapsed } = this.state;
    const { location } = this.props;
    return (
      <Sider
        style={{
          overflow: "auto",
          //   height: "100vh",
          //   position: "fixed",
          //   left: 0,
        }}
        collapsible
        collapsed={collapsed}
        onCollapse={this.onCollapse}
      >
        <div className="logo" />
        <Menu
          theme="dark"
          defaultSelectedKeys={["/"]}
          selectedKeys={[location.pathname]}
          mode="inline"
        >
          <Menu.Item key="/dashboard" icon={<HomeOutlined />}>
            <Link
              to={{
                pathname: "/dashboard",
                // state: { prevUrl: location.pathname },
              }}
            >
              Home
            </Link>
          </Menu.Item>
          {/* <Menu.Item key="2" icon={<DesktopOutlined />}>
            Option 2
          </Menu.Item> */}
          <SubMenu key="sub1" icon={<UserOutlined />} title="Student">
            <Menu.Item key="/student-personal-details">
              <Link to="/student-personal-details">Personal Details</Link>
            </Menu.Item>
            <Menu.Item key="/parents-details">
              <Link to="/parents-details">Parents Details</Link>
            </Menu.Item>
            <Menu.Item key="51">Certificate Management</Menu.Item>
            <Menu.Item key="53">Class & Section Allocation </Menu.Item>
            <Menu.Item key="54">Pass/Fail Entry</Menu.Item>
            <Menu.Item key="545">Discharging of Student</Menu.Item>
            <Menu.Item key="597">ID card Generation</Menu.Item>
          </SubMenu>
          <SubMenu key="sub2" icon={<TeamOutlined />} title="Team">
            <Menu.Item key="6">Team 1</Menu.Item>
            <Menu.Item key="8">Team 2</Menu.Item>
          </SubMenu>
          <Menu.Item key="9" icon={<FileOutlined />}>
            Files
          </Menu.Item>
        </Menu>
      </Sider>
    );
  }
}

export default withRouter(SideBar);
