import React from "react";
import { Modal, Form, Input, Button, Select } from "antd";
import { MinusCircleOutlined, PlusOutlined } from "@ant-design/icons";
import { connect } from "react-redux";
import {
  getClassSectionAndSubjects,
  clearClassSectionAndSubjects,
} from "../../Action/studentAction";

const { TextArea } = Input;
const { Option } = Select;
const classes = [
  { label: "Class 1", value: "Class 1" },
  { label: "Class 2", value: "Class 2" },
  { label: "Class 3", value: "Class 3" },
  { label: "Class 4", value: "Class 4" },
  { label: "Class 5", value: "Class 5" },
  { label: "Class 6", value: "Class 6" },
  { label: "Class 7", value: "Class 7" },
  { label: "Class 8", value: "Class 8" },
  { label: "Class 9", value: "Class 9" },
  { label: "Class 10", value: "Class 10" },
  { label: "Class 11", value: "Class 11" },
  { label: "Class 12", value: "Class 12" },
];
const section = [
  { label: "A", value: "A" },
  { label: "B", value: "B" },
  { label: "C", value: "C" },
  { label: "D", value: "D" },
  { label: "E", value: "E" },
];

class CreateStudentsDetailsModal extends React.Component {
  formRef = React.createRef();
  constructor(props) {
    super(props);
    this.state = {
      data: [],
    };
  }

  componentDidMount() {
    this.props.getClassSectionAndSubjects(this.props.match.params.id);
  }

//   componentDidUpdate(prevProps) {
//     if (
//       prevProps.updateTime !== this.props.updateTime &&
//       prevProps.studentId !== this.props.studentId
//     ) {
//       if (this.props.mode === "update") {
//         this.props.getClassSectionAndSubjects(this.props.studentId);
//       }
//     }

//     if (this.props.getClassSectionDetails.loading === false) {
//       if (this.props.getClassSectionDetails.response.result.length > 0) {
//         // this.setState({data:this.props.getClassSectionDetails.response.result[0].subjects});
//       }
//     }

//     //   setTimeout(() => {
//     //     this.setState({data:[]});
//     //  }, 2000);
//   }

  onFinish = (values) => {
    console.log("Received values of form:", values);
  };

  handleChange = () => {
    this.formRef.current.setFieldsValue({ sights: [] });
  };

  forceUpdateHandler = () => {
    this.forceUpdate();
    console.log(">>>>aaa");
  };

  shouldComponentUpdate(nextProps, nextState) {
    // console.log(nextProps, nextState);
    // console.log(this.props, this.state);

    if (this.props.data) {
      return true;
    }

    return false;
  }

  render() {
    const {
      visible,
      onAddClassSectionAndSubject,
      onCancel,
      mode,
      data,
    } = this.props;
    var result = [];
    // debugger
    result =
      this.props.getClassSectionDetails.loading === false
        ? this.props.getClassSectionDetails.response.result[0].subjects
        : "";
    //  const {subjects} = this.props.getClassSectionDetails.response.
    console.log(">>>>>onaddclass",this.formRef)

    const fields = [{ subject: "Hindi" }, { subject: "Hindi" }];
    // console.log(">>>>>>AAA", result ? result?.result[0]?.subjects : "");
    return (
      <Form
        // onValuesChange={(val) => this.props.onDataChange()}
        onClick={this.forceUpdateHandler}
        name="dynamic_form_nest_item"
        onFinish={this.onFinish}
        autoComplete="off"
        ref={this.formRef}
        // initialValue={fields}
      >
        <Button onClick={() => this.props.onClick()}>refresh</Button>
        <Form.Item
          name="class"
          label="Class"
          rules={[{ required: true, message: "Select class" }]}
        >
          <Select options={classes} onChange={this.handleChange} />
        </Form.Item>

        <Form.Item
          name="section"
          label="Section"
          rules={[{ required: true, message: "Select section" }]}
        >
          <Select options={section} onChange={this.handleChange} />
        </Form.Item>
        <Form.List
          name="subjects"
          initialValue={result ? result[0].subjects : ""}
        >
          {(fields, { add, remove }) => (
            <>
              {fields.map((field, index) => (
                <>
                  <Form.Item
                    {...field}
                    label={`Subject  ${index + 1}`}
                    name={[field.name, "subject"]}
                    fieldKey={[field.fieldKey, "subject"]}
                    rules={[{ required: true, message: "Enter Subject!" }]}
                    shouldUpdate={true}
                  >
                    <Input />
                  </Form.Item>

                  <MinusCircleOutlined onClick={() => remove(field.name)} />
                </>
              ))}

              <Form.Item>
                <Button
                  type="dashed"
                  onClick={() => add()}
                  block
                  icon={<PlusOutlined />}
                >
                  Subject
                </Button>
              </Form.Item>
            </>
          )}
        </Form.List>
      </Form>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    getClassSectionDetails: state.student.getClassSection,
  };
};
const mapDispatchToProps = {
  getClassSectionAndSubjects: getClassSectionAndSubjects,
  clearClassSectionAndSubjects: clearClassSectionAndSubjects,
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CreateStudentsDetailsModal);
