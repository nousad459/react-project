import React, { useState } from "react";

import {
  Button,
  Modal,
  Form,
  Radio,
  Row,
  Col,
  Input,
  DatePicker,
  Select,
} from "antd";
import { DownOutlined, UpOutlined } from "@ant-design/icons";

const { TextArea } = Input;
const { Option } = Select;

const CreateStudentsDetailsModal = ({ visible, onCreate, onCancel }) => {
  const [form] = Form.useForm();
  const [expand, setExpand] = useState(false);

  const getFields = () => {
    const count = expand ? 10 : 6;
    const children = [];
    for (let i = 0; i < count; i++) {
      children.push(
        <Col span={8} key={i}>
          <Form.Item
            name={`field-${i}`}
            label={`Field ${i}`}
            rules={[
              {
                required: true,
                message: "Input something!",
              },
            ]}
          >
            <Input placeholder="placeholder" />
          </Form.Item>
        </Col>
      );
    }
    return children;
  };

  const onFinish = (payload) => {
    console.log("Received values of form: ", payload);
  };

  return (
    <Modal
      visible={visible}
      title="Create Student Personal Details"
      okText="Create"
      cancelText="Cancel"
      onCancel={() => {
        onCancel();
        form.resetFields();
      }}
      width={800}
      onOk={() => {
        form
          .validateFields()
          .then((values) => {
            form.resetFields();
            onCreate(values);
          })
          .catch((info) => {
            console.log("Validate Failed:", info);
          });
      }}
    >
      <Form
        form={form}
        name="advanced_search"
        className="ant-advanced-search-form"
        onFinish={onFinish}
      >
        <Row gutter={(16, 16)}>
          <Col span={12}>
            <Form.Item
              name={`firstName`}
              label={`First Name`}
              rules={[
                {
                  required: true,
                  message: "Enter First Name!",
                },
              ]}
            >
              <Input placeholder="Enter First Name" />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name={`middleName`}
              label={`Middle Name`}
              // rules={[
              //   {
              //     required: true,
              //     message: "Enter Middle Name!",
              //   },
              // ]}
            >
              <Input placeholder="Enter Middle Name" />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={(16, 16)}>
          <Col span={12}>
            <Form.Item
              name={`lastName`}
              label={`Last Name`}
              rules={[
                {
                  required: true,
                  message: "Enter Last Name!",
                },
              ]}
            >
              <Input placeholder="Enter Last Name" />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name={`age`}
              label={`Student's Age`}
              rules={[
                {
                  required: true,
                  message: "Enter Student's Age",
                },
              ]}
            >
              <Input placeholder="Enter Student's Age" />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={(16, 16)}>
          <Col span={8}>
            <Form.Item
              name={`dob`}
              label={`DOB`}
              rules={[
                {
                  required: true,
                  message: "Enter Date Of Birth!",
                },
              ]}
            >
              <DatePicker />
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name={`gender`}
              label={`Gender`}
              rules={[
                {
                  required: true,
                  message: "Enter Gender!",
                },
              ]}
            >
              <Select placeholder="Select gender">
                <Option value="M">M</Option>
                <Option value="F">F</Option>
              </Select>
            </Form.Item>
          </Col>
          <Col span={8}>
            <Form.Item
              name={`grade`}
              label={`Grade`}
              rules={[
                {
                  required: true,
                  message: "Enter Student's Grade!",
                },
              ]}
            >
              <Input placeholder="Enter Student's Grade" />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={(16, 16)}>
          <Col span={12}>
            <Form.Item
              name={`motherName`}
              label={`Mother Name`}
              rules={[
                {
                  required: true,
                  message: "Enter Student's Mother Name!",
                },
              ]}
            >
              <Input placeholder="Enter Student's Mother Name" />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name={`fatherName`}
              label={`Father Name`}
              rules={[
                {
                  required: true,
                  message: "Enter Student's Father Name!",
                },
              ]}
            >
              <Input placeholder="Enter Student's Father Name" />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={(16, 16)}>
          <Col span={12}>
            <Form.Item
              name={`brotherName`}
              label={`Brother Name`}
              // rules={[
              //   {
              //     required: true,
              //     message: "Enter Student's Brother Name!",
              //   },
              // ]}
            >
              <Input placeholder="Enter Student's Brother Name" />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name={`sisterName`}
              label={`Sister Name`}
              // rules={[
              //   {
              //     required: true,
              //     message: "Enter Student's Sister Name!",
              //   },
              // ]}
            >
              <Input placeholder="Enter Student's Sister Name" />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={(16, 16)}>
          <Col span={12}>
            <Form.Item
              name={`mobileNumber`}
              label={`Mobile Number`}
              rules={[
                {
                  required: true,
                  message: "Enter Student's Mobile Number!",
                },
              ]}
            >
              <Input placeholder="Enter Student's Mobile Number" />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              name={`phoneNumber`}
              label={`Phone Number`}
              // rules={[
              //   {
              //     required: true,
              //     message: "Enter Student's Phone Number!",
              //   },
              // ]}
            >
              <Input placeholder="Enter Student's Phone Number" />
            </Form.Item>
          </Col>
        </Row>
        <Row gutter={(48, 16)}>
          <Col span={24}>
            <Form.Item
              name={`address`}
              label={`Address`}
              rules={[
                {
                  required: true,
                  message: "Enter Student's Address!",
                },
              ]}
            >
              <TextArea maxLength={100} placeholder="Enter Student's Address" />
            </Form.Item>
          </Col>
        </Row>
        {/* <Row>
          <Col span={24} style={{ textAlign: "right" }}>
            <Button type="primary" htmlType="submit">
              Search
            </Button>
            <Button
              style={{ margin: "0 8px" }}
              onClick={() => {
                form.resetFields();
              }}
            >
              Clear
            </Button>
            <a
              style={{ fontSize: 12 }}
              onClick={() => {
                setExpand(!expand);
              }}
            >
              {expand ? <UpOutlined /> : <DownOutlined />} Collapse
            </a>
          </Col>
        </Row> */}
      </Form>
    </Modal>
  );
};

export default CreateStudentsDetailsModal;
