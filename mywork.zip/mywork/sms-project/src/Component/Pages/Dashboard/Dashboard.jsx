import React, { useEffect } from "react";
import { BrowserRouter, Route, Switch, withRouter } from "react-router-dom";
import { Layout, message } from "antd";
import SideBar from "../../SideBar/SideBar";
import HeaderComponent from "../../Header/HeaderComponent";
import FooterComponent from "../../Footer/FooterComponent";
import BreadcrumbComponent from "../../BreadCumbs/BreadcumbComponent";
import PrivateRoute from "../../../Container/privateRoute";
import Home from "../../Pages/Home/Home";
import StudentPersonalDetails from "../../Pages/Student/PersonelDetails";
import ParentsDetails from "../../Pages/Student/ParentsDetails";
import AddClassSectionObject from "../../Modals/AddClassSection&Object";

const { Content } = Layout;

function Dashboard() {
  useEffect(() => {
    message.success("You have logged in");
  }, []);
  return (
    <BrowserRouter>
      <Layout style={{ minHeight: "100vh" }}>
        <SideBar />
        <Layout className="site-layout">
          <HeaderComponent />
          <Content style={{ margin: "0 16px" }}>
            <BreadcrumbComponent />
            <div
              className="site-layout-background"
              style={{ padding: 24, minHeight: 360 }}
            >
              <Switch>
                <Route exact path="/" component={PrivateRoute} />
                <Route exact path="/dashboard" component={Home} />
                <Route
                  path="/student-personal-details"
                  component={StudentPersonalDetails}
                />
                <Route path="/parents-details" component={ParentsDetails} />
                <Route path="/add-class-section/:id" component={AddClassSectionObject} />
                <Route
                  exact
                  path="*"
                  component={() => <h1>404 page not found</h1>}
                />
              </Switch>
            </div>
          </Content>
          <FooterComponent />
        </Layout>
      </Layout>
    </BrowserRouter>
  );
}

export default withRouter(Dashboard);
