import React, { useState, useEffect } from "react";
import { Button, Table, Space, Popconfirm, Tooltip } from "antd";
import { DeleteFilled, AppstoreAddOutlined, EditOutlined } from "@ant-design/icons";
import moment from "moment";
import CreateStudentsDetailsModal from "../../Modals/CreateStudentsDetails";
import AddClassSectionAndSubjectModal from "../../Modals/AddClassSection&Subject";
import { useDispatch, useSelector } from "react-redux";
import {
  createStudentDetailAction,
  getStudentDetails,
  addClassSectionAndSubjects,
  getClassSectionAndSubjects
} from "../../../Action/studentAction";

function PersonalDetails(props) {
  const dispatch = useDispatch();
  const student = useSelector((state) => state.student.createStudentDetails);
  const getClassSectionData = useSelector((state) => state.student.getClassSection);
  const studentDetails = useSelector(
    (state) => state.student.getStudentDetails
  );
  const [visible, setVisible] = useState(false);
  const [visible2, setVisibleClassModal] = useState(false);
  const [loading, setLoading] = useState(false);
  const [studentId, setStudentId] = useState(0);
  const [data, setData] = useState();
  const [reload, setReload] = useState(false);
  // const [section, setSection] = useState("");
  // const [subjects, setSubjects] = useState([]);
  const [mode, setMode] = useState("create");
  const onCreate = (payload) => {
    console.log("Received values of form: ", payload);
    const payload1 = {
      ...payload,
      dob: moment().format("YYYY-MM-DD"), // Wed, Jan 4, 2017
    };
    dispatch(createStudentDetailAction(payload1));
  };
  const onAddClassSectionAndSubject = (payload) => {
    const payload1 = {
      ...payload,
      studentId: studentId
    };
    console.log("Received values of form:??? ", payload1);
    dispatch(addClassSectionAndSubjects(payload1));
  };
  useEffect(() => {
    if (
      student.loading === false &&
      student.response?.message === "Student details added"
    ) {
      setVisible(false);
    }
  }, [student]);
  useEffect(() => {
    dispatch(getStudentDetails());
  }, []);
  useEffect(() => {
      console.log(">>>>", getClassSectionData);
    // debugger
    if (
      getClassSectionData.loading === false &&
      getClassSectionData.response?.message === "Fetched Class/Section and Student"
    ) {
          setData(getClassSectionData.response);
          

    }
  },[getClassSectionData]);

  const getClassSection=(studentId)=>{
    // setLoading(true);
    // dispatch(getClassSectionAndSubjects(studentId));
    // setTimeout(() => {
    //   //  setVisibleClassModal(true);
    //   //  setStudentId(studentId);
    //   //  setMode("update");

    // }, 2000);
    props.history.push(`/add-class-section/${studentId}`)
  }
 const onClickFromChild=()=>{
   console.log(">>>>>>reload")
    setReload(true);
  }
  const columns = [
    {
      title: "First Name",
      dataIndex: "firstName",
      key: "firstName",
    },
    {
      title: "Middle Name",
      dataIndex: "middleName",
      key: "middleName",
    },
    {
      title: "Last Name",
      dataIndex: "lastName",
      key: "lastName",
    },
    {
      title: "Age",
      key: "age",
      dataIndex: "age",
    },
    {
      title: "DOB",
      key: "dob",
      dataIndex: "dob",
      render: (_, record) => <span>{moment().format("DD-MM-YYYY")}</span>,
    },
    {
      title: "Mobile Number",
      key: "mobileNumber",
      dataIndex: "mobileNumber",
    },
    {
      title: "Action",
      key: "x",
      render: (_, record, i) => (
        <Space size="middle" key={i.toString()}>
          {/* {console.log(">>>>>",record)} */}
          <Popconfirm
            title="Are you sure you want to delete this item?"
            onConfirm={() => this.onDelete(record.CartPK)}
            okText="Yes"
            cancelText="No"
            key={i.toString()}
          >
            <Button
              key={i.toString()}
              type="danger"
              icon={<DeleteFilled />}
            ></Button>
          </Popconfirm>
          <Tooltip
            title="Add class/Section & Subject"
            color={"geekblue"}
            key={"geekblue"}
          >
            <Button
              key={i.toString()}
              type="primary"
              onClick={() => {
                setVisibleClassModal(true);
                setStudentId(record.id);
                setMode("create");
              }}
              icon={<AppstoreAddOutlined />}
            ></Button>
          </Tooltip>

          <Tooltip
            title="Add class/Section & Subject"
            color={"geekblue"}
            key={"geekblue"}
          >
            <Button
              key={i.toString()}
              type="primary"
              onClick={() => {
                getClassSection(record.id);
                
              }}
              icon={<EditOutlined />}
              loading={loading}
            ></Button>
          </Tooltip>
        </Space>
      ),
    },
  ];
  var result = [];
  result = studentDetails ? studentDetails.response?.result : "";
  var d = new Date();
   var time = d.getTime();
  return (
    <div>
      <Button
        type={"success"}
        onClick={() => {
          setVisible(true);
        }}
      >
        Add Personal Details
      </Button>
      <CreateStudentsDetailsModal
        visible={visible}
        onCreate={onCreate}
        onCancel={() => {
          setVisible(false);
        }}
      />
      <AddClassSectionAndSubjectModal
        visible={visible2}
        onAddClassSectionAndSubject={onAddClassSectionAndSubject}
        onCancel={() => {
          setVisibleClassModal(false);
          // setMode("create");
        }}
        mode={mode}
        studentId={studentId}
        updateTime={time}
        data={data}
        onDataChange={onClickFromChild}
      />
      <div style={{ padding: "10px" }}>
        <Table
          className="wetTd"
          columns={columns}
          dataSource={result && result.length ? result : ""}
          loading={result && result.length ? false : true}
        />
      </div>
    </div>
  );
}

export default PersonalDetails;
