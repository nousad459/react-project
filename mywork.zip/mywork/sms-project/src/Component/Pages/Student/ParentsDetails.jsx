import React, { useEffect } from "react";
import { Form, Input, Button, Space } from "antd";
import { MinusCircleOutlined, PlusOutlined } from "@ant-design/icons";


/*
Form.List#

<Form.List>
  {fields => (
    <div>
      {fields.map(field => (
        <Form.Item {...field}>
          <Input />
        </Form.Item>
      ))}
    </div>
  )}
</Form.List>

Note: You should not config Form.Item initialValue under Form.List. 
It always should be configured by Form.List initialValue or Form initialValues.

*/

const ParentsDetails = () => {
  const [form] = Form.useForm();
  const onFinish = (values) => {
    console.log("Received values of form:", values);
  };
  const fields = [{ first: "sdf", last: "dsfdsf" },{ first: "sdf", last: "dsfdsf" }];
  useEffect(() => {
    // form.setFieldsValue({ first: "sdf", last: "dsfdsf" });
  });
  const onFill = () => {
    form.setFieldsValue({ first: "sdf", last: "dsfdsf" });
  }
  return (
    <Form name="dynamic_form_nest_item" form={form} onFinish={onFinish} autoComplete="off">
      <Form.List name="users"  initialValue={fields}>
        {(fields, { add, remove }) => (
          <>
          {console.log(">>>>>>",fields)}
            {fields.map((field) => (
              <Space
                key={field.key}
                style={{ display: "flex", marginBottom: 8 }}
                align="baseline"
              >
                <Form.Item
                  {...field}
                  name={[field.name, "first"]}
                  fieldKey={[field.fieldKey, "first"]}
                  rules={[{ required: true, message: "Missing first name" }]}
                 
                >
                  <Input placeholder="First Name" />
                </Form.Item>
                <Form.Item
                  {...field}
                  name={[field.name, "last"]}
                  fieldKey={[field.fieldKey, "last"]}
                  rules={[{ required: true, message: "Missing last name" }]}
                >
                  <Input placeholder="Last Name" />
                </Form.Item>
                <MinusCircleOutlined onClick={() => remove(field.name)} />
              </Space>
            ))}
            <Form.Item>
              <Button
                type="dashed"
                onClick={() => {add(); onFill()}}
                block
                icon={<PlusOutlined />}
              >
                Add field
              </Button>
            </Form.Item>
          </>
        )}
      </Form.List>
      <Form.Item>
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </Form.Item>
    </Form>
  );
};

export default ParentsDetails;
