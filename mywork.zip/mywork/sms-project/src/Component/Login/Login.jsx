import React, { useEffect, useState } from "react";
import { useSelector, useDispatch, useStore } from "react-redux";
// import "antd/dist/antd.css";
import { Form, Input, Button, Checkbox, Row, Col } from "antd";
import { UserOutlined, LockOutlined } from "@ant-design/icons";
import { loginUserAction } from "../../Action/authenticationActions";
import { setCookie } from "../../Utils/cookies";

const LoginComponent = (props) => {
  const dispatch = useDispatch();
  const [loading, setLoading] = useState(false);
  const user = useSelector((state) => state.user.login);
  useEffect(() => {
    if (user.loading === false && user.response?.message === "Login Success") {
      setCookie("token", user.response?.result?.access_token);
      props.history.push("/dashboard");
      setLoading(false);
    }
    if (user.response?.message === "wrong email/password combination") {
      setLoading(false);
    }
    if (!user.response?.result) {
      setLoading(false);
    }
  },[user]);
  const onFinish = (values) => {
    console.log("Received values of form: ", values);
    const payload = {
      email: values.user,
      password: values.password,
    };
    setLoading(true);
    setTimeout(() => {
      dispatch(loginUserAction(payload));
    }, 2000);
  };

  return (
    <Row
      className="login-row"
      type="flex"
      justify="space-around"
      align="middle"
    >
      <Col span="8">
        <Form
          name="normal_login"
          className="login-form"
          initialValues={{
            remember: true,
          }}
          onFinish={onFinish}
        >
          <h2 className="logo">
            <span>logo</span>
          </h2>
          <Form.Item
            name={"user"}
            rules={[
              {
                required: true,
                // message: "Please input your Username!",
                type: "email",
              },
            ]}
          >
            <Input
              prefix={<UserOutlined className="site-form-item-icon" />}
              placeholder="Username"
            />
          </Form.Item>
          <Form.Item
            name="password"
            rules={[
              {
                required: true,
                message: "Please input your Password!",
              },
            ]}
          >
            <Input
              prefix={<LockOutlined className="site-form-item-icon" />}
              type="password"
              placeholder="Password"
            />
          </Form.Item>
          <Form.Item>
            <Form.Item name="remember" valuePropName="checked" noStyle>
              <Checkbox>Remember me</Checkbox>
            </Form.Item>

            <a className="login-form-forgot" href="">
              Forgot password
            </a>
          </Form.Item>

          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              size="large"
              className="login-form-button"
              loading={loading}
            >
              Log in
            </Button>
            Or <a href="">register now!</a>
          </Form.Item>
        </Form>
      </Col>
    </Row>
  );
};

export default LoginComponent;
