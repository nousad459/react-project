import * as types from "./index";

/*Action for create student details */
export const createStudentDetailAction = (payload) => {
  return {
    type: types.CREATE_STUDENT_DETAILS,
    payload,
  };
};

/*Action for create student details */
export const getStudentDetails = () => {
  return {
    type: types.GET_STUDENT_DETAILS,
  };
};

/*Action for create student details */
export const addClassSectionAndSubjects = (payload) => {
  return {
    type: types.ADD_CLASS_SECTION_SUBJECT_DETAILS,
    payload
  };
};

/*Action for create student details */
export const getClassSectionAndSubjects = (studentId) => {
  return {
    type: types.GET_CLASS_SECTION_SUBJECT_DETAILS,
    studentId
  };
};

/*Action for create student details */
export const clearClassSectionAndSubjects = () => {
  return {
    type: types.CLEAR_CLASS_SECTION_SUBJECT_DETAILS,
  };
};

