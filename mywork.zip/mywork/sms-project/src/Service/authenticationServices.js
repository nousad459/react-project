import * as api from "../Utils/api";

/*Service for get search parts data */
export const loginService = async (payload) => {
  try {
    let response = await api.post("api/userLogin/", payload);
    return response;
  } catch (error) {
    return error;
  }
};


/*Service for user logout */
export const logoutService = async (payload) => {
  try {
    let response = await api.post("api/logout/", payload);
    return response;
  } catch (error) {
    return error;
  }
};

