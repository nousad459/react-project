import * as api from "../Utils/api";

/*Service for get search parts data */
export const createStudentDetailsService = async (payload) => {
  try {
    let response = await api.post("api/createStudentDetails/", payload);
    return response;
  } catch (error) {
    return error;
  }
};

/*Service for get search parts data */
export const getStudentDetailsService = async () => {
  try {
    let response = await api.get("api/getStudentDetails/");
    return response;
  } catch (error) {
    return error;
  }
};

/*Service for get search parts data */
export const addClassSectionAndStudentService = async (payload) => {
  try {
    let response = await api.post("api/addStudentClassSectionAndSubjects/", payload);
    return response;
  } catch (error) {
    return error;
  }
};

/*Service for get search parts data */
export const getClassSectionAndStudentService = async (studentId) => {
  try {
    let response = await api.get("api/getStudentClassSectionAndSubjects?studentId="+studentId);
    return response;
  } catch (error) {
    return error;
  }
};


